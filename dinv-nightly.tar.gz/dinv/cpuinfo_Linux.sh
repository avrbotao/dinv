
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code in this file is part of "dinv" (dynamic inventory tool)   |
###   |   as developed and released by alexandre botao <from botao dot org> , |
###   |   available for download from the following public repositories:      |
###   |                                                                       |
###   |   https://sourceforge.net/u/avrbotao/                                 |
###   |   https://gitlab.com/alexandre.botao/                                 |
###   |   https://github.com/avrbotao/                                        |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

#!/bin/bash
#_________________________________________________________________________
#
#	cpuinfo(Linux)		2018-04-17		botao
#_________________________________________________________________________
#
TMP=/tmp/.cil.tmp
#_________________________________________________________________________
#
nproc=n/a
vproc=n/a
ncore=n/a
ncoresperproc=n/a
nstrandspercore=n/a
speedinmhz=0
score=0

if test -s /usr/bin/lscpu
then
	/usr/bin/lscpu > $TMP 2>&1
	if test -s $TMP
	then
		nproc=`grep "^Socket(s):" $TMP | cut -d ':' -f 2 | tr -d " "`
		vproc=`grep "^CPU(s):" $TMP | cut -d ':' -f 2 | tr -d " "`
		ncoresperproc=`grep "^Core(s) per socket:" $TMP | cut -d ':' -f 2 | tr -d " "`
		ncore=`expr $nproc \* $ncoresperproc`
		nstrandspercore=`grep "^Thread(s) per core:" $TMP | cut -d ':' -f 2 | tr -d " "`
		speedinmhz=`grep "^CPU MHz:" $TMP | cut -d ':' -f 2 | cut -d '.' -f 1 | tr -d " "`
	fi
else
	cat /proc/cpuinfo | sort | uniq -c | tr "\t" " " > $TMP
	if test -s $TMP
	then
		nproc=`grep -c " physical id " $TMP`
		vproc=`grep -c " processor " $TMP`
		ncoresperproc=`grep -c " core id " $TMP`
		ncore=`expr $nproc \* $ncoresperproc`
		nstrandspercore=`expr $vproc / $ncore`
		speedinmhz=`grep " cpu MHz " $TMP | cut -d ':' -f 2 | cut -d '.' -f 1 | tr -d " "`
	fi
fi

# speedinghz=`echo "scale=2; $speedinmhz/1000" | bc`
speedinghz=`expr $speedinmhz / 1000`

echo "Total number of physical processors: $nproc"
echo "Number of virtual processors: $vproc"
echo "Total number of cores: $ncore"
echo "Number of cores per physical processor: $ncoresperproc"
echo "Number of hardware threads (strands or vCPUs) per core: $nstrandspercore"
echo "Processor speed: $speedinmhz MHz ($speedinghz GHz)"

rm -f $TMP

#_________________________________________________________________________
# vi:nu ts=8
