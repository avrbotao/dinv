
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code in this file is part of "dinv" (dynamic inventory tool)   |
###   |   as released by alexandre botao <alexandre at botao dot org>         |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

SOLIGN="/devices|/system/contract|/proc|/etc/mnttab|/etc/svc/volatile|/system/object|/etc/dfs/sharetab|/dev/fd|/var/run"
LNXIGN=" proc | sysfs | devpts | tmpfs | efivarfs | binfmt_misc | rpc_pipefs | nfs | acfs | tracefs "
inodez () {
	HN=$1
	cat <<EOI
		case \`uname\` in
			Linux)	### Inodes IFree IUsed IUse% Mounted
				if mount | grep " acfs " >/dev/null 2>&1
				then
					mount | egrep -v -e "$LNXIGN" | awk '{print \$3}' | xargs -l df -i | grep -v IUsed | awk -f ${INVDIR}/linuxdfi.awk | tr -d "%" > /tmp/.x.o 2> /tmp/.x.e
				else
					df -l -i | egrep -i -v -e "devtmpfs|tmpfs" | awk -f ${INVDIR}/linuxdfi.awk | tr -d "%" > /tmp/.x.o 2> /tmp/.x.e
				fi
				zero=\$?
			;;
			AIX)	### Inodes Ifree Iused %Iused Mounted
				mount | grep " jfs" | awk '{print \$2}' | xargs -l df -v | grep -v Iused | awk 'OFS=";" {print \$7+\$6,\$7,\$6,\$8,\$9}' | tr -d "%" > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			SunOS)	### total i-nodes | free i-nodes | used i-nodes | % i-nodes used | Mounted
				df -l -t | tr "()" "  " | awk -f ${INVDIR}/solarisdfi.awk | egrep -i -v -e "$SOLIGN" | tr -d "%" > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			HP-UX)	### total i-nodes | free i-nodes | used i-nodes | % i-nodes used | Mounted
				mount | egrep -i -v -e "/net|/cdrom|/nfs" | awk '{print \$1}' | xargs -l df -i | awk -f ${INVDIR}/hpuxdfi.awk > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			*) echo "${HN};O.S. (\`uname\`) unprepared" ; exit 1 ;;
		esac
		if test "\$zero" -eq 0
		then
			cat /tmp/.x.o | sed "s/^/${HN};/"
			rm -f /tmp/.x.o /tmp/.x.e
		else
			echo "${HN};n/a" ; exit 1
		fi
EOI
}
if test -z "$INVDIR"
then
	echo ">>> $0: INVDIR not set" >&2
	exit 1
else
	export INVDIR
fi
if test "$1" = "--header"
then
	shift
	cat ${INVDIR}/header-iiz.csv
fi
if test $# -eq 0
then
	HN=`hostname | cut -d '.' -f 1`
	inodez $HN | sh
else
	for HN in $*
	do
		inodez $HN | ssh $SSHOPT $HN "sh"
	done
fi
# vi:nu ts=4
