
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code in this file is part of "dinv" (dynamic inventory tool)   |
###   |   as released by alexandre botao <alexandre at botao dot org>         |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

patchz () {
	HN=$1
	cat <<EOI
		case \`uname\` in
			Linux)
				if test -d /var/log/apt
				then
					ls -lt --time-style="long-iso" /var/log/apt | grep -o '\([0-9]\{2,4\}[- ]\)\{3\}[0-9]\{2\}:[0-9]\{2\}' -m 1 > /tmp/.x.o 2> /tmp/.x.e
				else
					rpm -qa --last kernel | head -1 | tr -s " " | cut -d ' ' -f 2- > /tmp/.x.o 2> /tmp/.x.e
				fi
				zero=\$?
			;;
			AIX)
				lslpp -q -c -h -Or \`lslpp -q -c -w /unix | cut -d: -f2\` 2> /tmp/.x.e | tail -1 | cut -d: -f7-8 | tr ";" "," > /tmp/.x.o
				zero=\$?
			;;
			SunOS)
				ls -terd /var/sadm/patch/* 2> /tmp/.x.e | tail -1 | awk '{print \$6,\$7,\$9,\$8}' > /tmp/.x.o
				zero=\$?
			;;
			HP-UX)
				swlist 2> /tmp/.x.e | grep QPKBASE | head -1 | tr "\t" " " | tr -s " " > /tmp/.x.o
				zero=\$?
			;;
			*) echo "${HN};O.S. (\`uname\`) unprepared" ; exit 1 ;;
		esac
		if test "\$zero" -eq 0
		then
			echo "${HN};\`cat /tmp/.x.o\`"
			rm -f /tmp/.x.o /tmp/.x.e
		else
			echo "${HN};n/a" ; exit 1
		fi
EOI
}
if test $# -eq 0
then
	HN=`hostname | cut -d '.' -f 1`
	patchz $HN | sh
else
	for HN in $*
	do
		patchz $HN | ssh $SSHOPT $HN "sh"
	done
fi
# vi:nu ts=4
