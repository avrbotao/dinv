
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code in this file is part of "dinv" (dynamic inventory tool)   |
###   |   as released by alexandre botao <alexandre at botao dot org>         |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###


DINVCONF=.dinv.conf	### default $HOME
	[ -s ${HOME}/${DINVCONF} ] && . ${HOME}/${DINVCONF}
	[ -s ${INVDIR}/${DINVCONF} ] && . ${INVDIR}/${DINVCONF}

SOLIGN="^/usr/lib/libc|^objfs|^/dev/odm|^/platform/|^Filesystem|^/devices|^ctfs|^proc|^mnttab|/etc/svc/volatile|^sharefs|^/.SUNW|^fd|/var/run|/dev/vx/dmp|/dev/vx/rdmp"
### LNXIGN=" proc | sysfs | devpts | tmpfs | efivarfs | binfmt_misc | rpc_pipefs | nfs | acfs "
LNXIGN="^systemd|^cgroup |^devtmpfs|^securityfs|^pstore|^configfs|^binfmt_misc|^mqueue|^hugetlbfs|^debugfs|^tracefs| proc | sysfs | devpts | tmpfs | efivarfs | binfmt_misc | rpc_pipefs | nfs "
fsusagez () {
	HN=$1
	YMD=`date +%Y%m%d`
	HMS=`date +%H%M%S`
	cat <<EOI
		case \`uname\` in
			Linux) ### Filesystem           1K-blocks    Used Available Use% Mounted 
				mount | egrep -v -e "$LNXIGN" | awk '{print \$3}' | xargs -l df -k | grep -v -i Filesystem | awk 'NF==6{print \$0};NF==1{D=\$1};NF==5{print D,\$0}' > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			AIX) ### Filesystem    1024-blocks      Free %Used    Iused %Iused Mounted 
				mount | grep " jfs" | awk '{print \$2}' | xargs -l df -k | grep -v Filesystem | awk '{print \$1,\$2,\$2-\$3,\$3,\$4,\$NF}' > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			SunOS) ### Filesystem            kbytes    used   avail capacity  Mounted 
				df -k | egrep -i -v -e "$SOLIGN" > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			HP-UX) ### Filesystem          kbytes    used   avail %used Mounted 
				mount | egrep -i -v -e "/net|/cdrom|/nfs" | awk '{print \$1}' | xargs -l bdf | grep -v Filesystem | awk 'NF==6{print \$0};NF==1{D=\$1};NF==5{print D,\$0}' > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			*) echo "${HN};O.S. (\`uname\`) unprepared" ; exit 1 ;;
		esac
		if test "\$zero" -eq 0
		then
			cat /tmp/.x.o | tr " \t" ";;" | tr -s ";" | sed "s/^/${HN};${YMD};${HMS};/"
			rm -f /tmp/.x.o /tmp/.x.e
		else
			echo "${HN};n/a" ; exit 1
		fi
EOI
}
if test $# -eq 0
then
	HN=`hostname | cut -d '.' -f 1`
	fsusagez $HN | sh
else
	for HN in $*
	do
		fsusagez $HN | ssh $SSHOPT $HN "sh"
	done
fi
# vi:nu ts=4
