
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code in this file is part of "dinv" (dynamic inventory tool)   |
###   |   as developed and released by alexandre botao <from botao dot org> , |
###   |   available for download from the following public repositories:      |
###   |                                                                       |
###   |   https://sourceforge.net/u/avrbotao/                                 |
###   |   https://gitlab.com/alexandre.botao/                                 |
###   |   https://github.com/avrbotao/                                        |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

#!/bin/bash

if test -x /usr/bin/kstat
then
	/usr/bin/kstat -m cpu_info | egrep "chip_id|core_id|module: cpu_info" > /var/tmp/cpu_info.log
else
	exit
fi

nproc=`(grep chip_id /var/tmp/cpu_info.log | awk '{ print $2 }' | sort -u | wc -l | tr -d ' ')`
ncore=`(grep core_id /var/tmp/cpu_info.log | awk '{ print $2 }' | sort -u | wc -l | tr -d ' ')`
vproc=`(grep 'module: cpu_info' /var/tmp/cpu_info.log | awk '{ print $4 }' | sort -u | wc -l | tr -d ' ')`

nstrandspercore=$(($vproc/$ncore))
ncoresperproc=$(($ncore/$nproc))

speedinmhz=`(/usr/bin/kstat -m cpu_info | grep clock_MHz | awk '{ print $2 }' | sort -u)`
speedinghz=`echo "scale=2; $speedinmhz/1000" | bc`

echo "Total number of physical processors: $nproc"
echo "Number of virtual processors: $vproc"
echo "Total number of cores: $ncore"
echo "Number of cores per physical processor: $ncoresperproc"
echo "Number of hardware threads (strands or vCPUs) per core: $nstrandspercore"
echo "Processor speed: $speedinmhz MHz ($speedinghz GHz)"

test "$1" = "--fast" && exit

# now derive the vcpu-to-core mapping based on above information #

echo -e "\n** Socket-Core-vCPU mapping **"
let linenum=2

for ((i = 1; i <= ${nproc}; ++i ))
do
        chipid=`sed -n ${linenum}p /var/tmp/cpu_info.log | awk '{ print $2 }'`
        echo -e "\nPhysical Processor $i (chip id: $chipid):"

        for ((j = 1; j <= ${ncoresperproc}; ++j ))
        do
                let linenum=($linenum + 1)
                coreid=`sed -n ${linenum}p /var/tmp/cpu_info.log | awk '{ print $2 }'`
                echo -e "\tCore $j (core id: $coreid):"

                let linenum=($linenum - 2)
                vcpustart=`sed -n ${linenum}p /var/tmp/cpu_info.log | awk '{ print $4 }'`

                let linenum=(3 * $nstrandspercore + $linenum - 3)
                vcpuend=`sed -n ${linenum}p /var/tmp/cpu_info.log | awk '{ print $4 }'`

                echo -e "\t\tvCPU ids: $vcpustart - $vcpuend"
                let linenum=($linenum + 4)
        done
done

rm /var/tmp/cpu_info.log
