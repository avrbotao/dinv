
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code in this file is part of "dinv" (dynamic inventory tool)   |
###   |   as released by alexandre botao <alexandre at botao dot org>         |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

#	listen info
h=`hostname | cut -d '.' -f 1`
o=`uname`
t4=/tmp/.li4.t.
t6=/tmp/.li6.t.
case $o in
	AIX)
		netstat -an > $t4
		for i in tcp tcp4 tcp6 
		do
			af=`echo $i | sed "s/tcp/inet/"`
			grep "^${i} " $t4 > ${t6}.${i}
			test -s ${t6}.${i} && grep LISTEN ${t6}.${i} | awk '{print $4}' | awk -F'.' '{ for (i=1;i<NF;i++) printf("%s%s",$i,(i<NF-1?".":";")); print $NF}' | sed "s/^/$h;${i};$af;/"
		done
		for i in udp udp4 udp6
		do
			af=`echo $i | sed "s/udp/inet/"`
			grep "^${i} " $t4 > ${t6}.${i}
			test -s ${t6}.${i} && cat ${t6}.${i} | awk '{print $4}' | awk -F'.' '{ for (i=1;i<NF;i++) printf("%s%s",$i,(i<NF-1?".":";")); print $NF}' | sed "s/^/$h;${i};$af;/"
		done
	;;
	HP-UX)
		netstat -an -f inet  > $t4
		netstat -an -f inet6 > $t6
		grep "^tcp.*LISTEN" $t4 | awk '{print $4}' | awk -F'.' '{ for (i=1;i<NF;i++) printf("%s%s",$i,(i<NF-1?".":";")); print $NF}' | sed "s/^/$h;tcp;inet;/"
		grep "^tcp.*LISTEN" $t6 | awk '{print $4}' | awk -F'.' '{ for (i=1;i<NF;i++) printf("%s%s",$i,(i<NF-1?".":";")); print $NF}' | sed "s/^/$h;tcp;inet6;/"
		grep "^udp"         $t4 | awk '{print $4}' | awk -F'.' '{ for (i=1;i<NF;i++) printf("%s%s",$i,(i<NF-1?".":";")); print $NF}' | sed "s/^/$h;udp;inet;/"
		grep "^udp"         $t6 | awk '{print $4}' | awk -F'.' '{ for (i=1;i<NF;i++) printf("%s%s",$i,(i<NF-1?".":";")); print $NF}' | sed "s/^/$h;udp;inet6;/"
	;;
	Linux)
		type netstat >/dev/null 2>&1 || exit 1
		netstat -ln > $t4
		for i in tcp tcp6 
		do
			af=`echo $i | sed "s/tcp/inet/"`
			grep "^${i} " $t4 > ${t6}.${i}
			test -s ${t6}.${i} && grep LISTEN ${t6}.${i} | awk '{print $4}' | awk -F':' '{ for (i=1;i<NF;i++) printf("%s%s",$i,(i<NF-1?":":";")); print $NF}' | sed "s/^/$h;${i};$af;/"
		done
		for i in udp udp6
		do
			af=`echo $i | sed "s/udp/inet/"`
			grep "^${i} " $t4 > ${t6}.${i}
			test -s ${t6}.${i} && cat ${t6}.${i} | awk '{print $4}' | awk -F':' '{ for (i=1;i<NF;i++) printf("%s%s",$i,(i<NF-1?":":";")); print $NF}' | sed "s/^/$h;${i};$af;/"
		done
	;;
	SunOS)
		for f in inet inet6
		do
			netstat -P tcp -f $f -an | egrep -v -e "^$|UDP|Local|---" | grep LISTEN | nawk '{print $1}' | nawk -F'.' '{ for (i=1;i<NF;i++) printf("%s%s",$i,(i<NF-1?".":";")); print $NF}' | sed "s/^/$h;tcp;$f;/"
		done
		for f in inet inet6
		do
			netstat -P udp -f $f -an | egrep -v -e "^$|UDP|Local|---" | nawk '{print $1}' | nawk -F'.' '{ for (i=1;i<NF;i++) printf("%s%s",$i,(i<NF-1?".":";")); print $NF}' | sed "s/^/$h;udp;$f;/"
		done
	;;
	*) echo "SSHFAIL" ;;
esac
cd /tmp
rm -f ${t4}* ${t6}*
# vi:nu ts=4
