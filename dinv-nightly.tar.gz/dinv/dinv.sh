
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

# SWNAME="dinv"
# SWVERS="0.0.0"		### SEE BELOW
# SWDATE="2021/01/01"		### DITTO
# SWDESC="dynamic inventory"
# SWTAGS="script,foss"
# SWCOPY="GPLv3"
# SWAUTH="alexandre at botao dot org"

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code in this file is part of "dinv" (dynamic inventory tool)   |
###   |   as released by alexandre botao <alexandre at botao dot org>         |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

#THISPATH=$0

#THISFILE=`basename $0`
#THISNAME=`basename $THISFILE .sh`

#THISUSER=username

### 
### 
###         /\          _____________________________________________________
###        /  \        |                                                     |
###       / OO \       |   dinv.sh                               collector   |
###       \ \/ /       |   (c) [2010-]2021           alexandre v. r. botao   |
###        \  /        |_____________________________________________________|
###         \/
### 
### 


#_______________________________________________________________#
#								#


BAC=dinv.sh
BVERSION=2.4.21		# superseded by info.env
BRELEASE=2019/11/26	# ditto

CORPNAME=n/a		# corp name
SITENAME=n/a		# site name
DINVHOST=n/a		# nickname
OPSYNAME=n/a		# operating system name
OPSYVERS=n/a		# operating system version
VENDORID=n/a		# manufacturer name
MANMODEL=n/a		# manufacturer model
MACHVIRT=n/a		# machine virtualization type (lpar,vm,...)
PROCARCH=n/a		# processor architecture
PROCNAME=n/a		# processor model name
PROCOUNT=n/a		# processor count
PROCLOCK=n/a		# processor clock (MHz)
RAMSIZEG=n/a		# ram size  (GB)
SWAPSIZE=n/a		# swap size (GB)
HWSERIAL=n/a		# hardware serial number
IPV4ADDR=n/a		# ip v4 address
DINVDATE=n/a		# inspection date (YYYY/MM/DD)
DINVTIME=n/a		# inspection time (HH:MM:SS)
HCUPTIME=n/a		# host current uptime
HOSTCLAS=n/a		# host class (production, qa, development, test...)
HOSTDESC=n/a		# host description (dbs, web, ...)
DCOMMENT=n/a		# additional host info
DENVIRON=n/a		# default global properties/environment
LENVIRON=n/a		# local host properties/environment
DINVUSRK=n/a		# user count
DINVGRPK=n/a		# group count
DINVOLGR=n/a		# volume group count
DINVPVOL=n/a		# physical volume count
DINVLVOL=n/a		# logical volume count
DINVFSYS=n/a		# local file system count
DINVPMON=n/a		# oracle db count
DINVPERF=n/a		# monitor performance ?
DNSERVER=n/a		# 1st dns
DGATEWAY=n/a		# default router
DINVNICS=n/a		# NICs
DINVIPAS=n/a		# IP addresses
DINMASKS=n/a		# netmasks
DINVMACS=n/a		# MACs
DISTATUS=n/a		# operational status
DINVUKEY=n/a		# unique host key
DINVACIP=n/a		# access ip address
DINVHONA=n/a		# host name
DINVTIZO=n/a		# time zone
DINVPLOC=n/a		# physical location
DINVSOCS=n/a		# processor sockets
DINVCORS=n/a		# processor cores
DINVSMTS=n/a		# simultaneous multi threads
DINVTHRS=n/a		# total threads
DINVHBAS=n/a		# HBAs
DINVWWNS=n/a		# WWNs
DINVLOAD=n/a		# average load
VPGUESTS=n/a		# virtual/partitioned guests
DINVTAGS=n/a		# tags
OPSYLEVL=n/a		# operating system level
DINVVLAN=n/a		# vlan description
DINVINAT=n/a		# nat addr
DINVRUNS=n/a		# running apps
DINVVERS=n/a		# installed version
PATCHDAY=n/a		# latest kernel patch
DINVUTUN=n/a		# ksplice uptrack-uname

HOSTINFO=n/a		# server documentation file
LOCATION=n/a		# physical or container location

INVQUIET=false
export INVQUIET

VFLAG=false
export VFLAG

INVDIR=/usr/local/dinv
INVDHN=${INVDIR}/thishostname.dinv.d
INVSCR=${INVDIR}/${BAC}
COLDIR=$INVDIR/coletas
DRMLOG=$INVDIR/dinvrm.log
PSOUT=${INVDIR}/.ps.out
MYPID=$$
INVFMT=new
[ "$INVSEP" = "" ] && INVSEP=";"

TEMPSTAB=${INVDIR}/share.tab
TEMPMTAB=${INVDIR}/mount.vfs
TEMPMNFS=${INVDIR}/mount.nfs

INFOENV=${INVDIR}/info.env
### INFOENV=${INVDIR}/dinvx/info.env

TEMPROOT=/
TEMPTEMP=${TEMPROOT}tmp
TEMPDINV=${TEMPTEMP}/.dinv.tmp.d

export TEMPDINV

TEMPMISC=${TEMPDINV}/.dinvmisc
TEMPCRON=${TEMPDINV}/.dinvcron
TEMPSWAP=${TEMPDINV}/.dinvswap
TEMPFREE=${TEMPDINV}/.dinvfree
TEMPINFO=${TEMPDINV}/.dinvinfo
TEMPERRO=${TEMPDINV}/.dinverro

TEMPWORKLIST=${TEMPDINV}/.lni.tmp.
TEMPLINKLIST=${TEMPDINV}/.lni.lnk.
TEMPADDRLIST=${TEMPDINV}/.lni.adr.
TEMPMASKLIST=${TEMPDINV}/.lni.msk.
TEMPMACALIST=${TEMPDINV}/.lni.mac.

TMPNET=${TEMPDINV}/.dinvnetz

DINVDISK=0
DISKSIZE=0

SYSDIR="/"

IAMGROOT=0
indulgeflag=0

#_______________________________________________________________________
#

isipv4 () {
	ip=$1
	if test -z "$ip"
	then
		echo no
	else
		octets=`echo $ip | tr "." " "`
		if test `echo $octets | wc -w` -eq 4
		then
			for i in `echo $octets`
			do
				if `echo $i | egrep -e "^[0-9]{1,3}$" >/dev/null`
				then
					if test $i -lt 0 -o $i -gt 255
					then
						echo no
						return
					fi
				else
					echo no
					return
				fi
			done
			echo yes
		else
			echo no
		fi
	fi
}

#_______________________________________________________________________
#

xia2dia () {
	typeset -i10 daz
	typeset -i16 xaz
	xad=$1
	for i in 0 1 2 3
	do
		ci=`expr 1 + $i \* 2`
		cf=`expr $ci + 1`
		xoc=`echo $xad | cut -c ${ci}-${cf}`
		xaz=16#${xoc}
		daz=$xaz
		[ $i -gt 0 ] && echo ".\c"
		echo "$daz\c"
	done
	echo
}

dinvrm () {		### only -f | -rf allowed
	FLG=$1
	shift
	test "$FLG" = "-fr" && FLG="-rf"
	CWD=`pwd`
	for i in $@
	do
		TMPSTAMP=`date +%Y/%m/%d_%H:%M:%S`
		### echo "=== ${TMPSTAMP} === dinvrm ($i)" >> $DRMLOG
		if test "$FLG" = "-rf" -a -d $i
		then
			cd $CWD
			if cd $i 2>/dev/null
			then
				XWD=`pwd`
				cd $CWD
				for j in `echo $SYSDIR`
				do
					if test "$XWD" = "$j"
					then
						echo ">>> ${TMPSTAMP} >>> untouchable ($i)" >> $DRMLOG
					else
						/bin/rm $FLG $i
						echo "=== ${TMPSTAMP} === dinvrm ($FLG) dir ($i) status ($?)" >> $DRMLOG
					fi
				done
			else
				echo ">>> ${TMPSTAMP} >>> unreachable ($i)" >> $DRMLOG
			fi
		elif test -f $i
		then
			/bin/rm $FLG $i
			echo "=== ${TMPSTAMP} === dinvrm ($FLG) file ($i) status ($?)" >> $DRMLOG
		else
			echo ">>> ${TMPSTAMP} >>> file ($i) not found" >> $DRMLOG
		fi
	done
	cd $CWD
}

dinvhour () {
	TMPSTAMP=`date +%Y/%m/%d_%H:%M:%S`
	DINVDATE=`echo $TMPSTAMP | cut -d '_' -f 1`
	DINVTIME=`echo $TMPSTAMP | cut -d '_' -f 2`
	OUTSTAMP=`echo $TMPSTAMP | tr -d "/:"`
	INVOUT=$INVDIR/dinv_${OUTSTAMP}
}

dinvroom () {
	cd /tmp
	test -d ${TEMPDINV} && dinvrm -fr ${TEMPDINV}
	mkdir -p ${TEMPDINV} 2>/dev/null
	if [ $? -ne 0 ]
	then
		echo ">>> no room for ${TEMPDINV} <<<" 1>&2
		exit 1
	fi
}

dinvinit () {
	PATH=/sbin:/usr/sbin:/bin:/usr/bin:$PATH
	tmpid=`id`
	runid=`echo ${tmpid} | cut -d ' ' -f 1`
	if test -z "${runid}"
	then
		echo ">>> unreachable id <<<" 1>&2
		exit 1
	else
		if [ "${runid}" != "uid=0(root)" ]
		then
			if test $indulgeflag = 1
			then
				IAMGROOT=0
			else
				echo ">>> inadequate user : ${runid} <<<" 1>&2
				exit 1
			fi
		else
			IAMGROOT=1
		fi
	fi
	[ -d $INVDIR ] || mkdir -p $INVDIR 2>/dev/null
	if test $? -ne 0
	then
		echo ">>> create directory ($INVDIR) failed. using current directory ($PWD)"
		INVDIR=$PWD
		export INVDIR
	fi

	INVDHN=${INVDIR}/thishostname.dinv.d
	INVSCR=${INVDIR}/${BAC}
	COLDIR=$INVDIR/coletas
	DRMLOG=$INVDIR/dinvrm.log
	PSOUT=${INVDIR}/.ps.out
	TEMPSTAB=${INVDIR}/share.tab
	TEMPMTAB=${INVDIR}/mount.vfs
	TEMPMNFS=${INVDIR}/mount.nfs
	INFOENV=${INVDIR}/info.env

	[ -d $COLDIR ] || mkdir -p $COLDIR 2>/dev/null
	if test $? -ne 0
	then
		echo ">>> create directory ($COLDIR) failed. using current directory ($PWD)"
		COLDIR=$PWD
	fi

	if test -s ${INVDIR}/rootdirs.list
	then
		ROOTDIRLST=`cat ${INVDIR}/rootdirs.list`
	else
		CSRDL="/adm,/admin,/apps,/audit,/bin,/bmc,/boot,/cdrom,/cgroup,/crash,/db,/dbextract,/dev,/devices,/etc,/export,/flar_images,/historico,/home,/kernel,/lab,/lib,/lib64,/local,/local64,/lost+found,/lpp,/media,/mksysb_images,/mnt,/net,/opt,/perf,/platform,/proc,/root,/rpms,/run,/sbin,/selinux,/srv,/stand,/sun,/SUN,/sys,/sysout,/system,/tcb,/tftpboot,/tmp,/tools,/tst,/u,/UNIX,/usr,/var,/vol"
		ROOTDIRLST=" /adm /admin /apps /audit /bin /bmc /boot /cdrom /cgroup /crash /db /dbextract /dev /devices /etc /export /flar_images /historico /home /kernel /lab /lib /lib64 /local /local64 /lost+found /lpp /media /mksysb_images /mnt /net /opt /perf /platform /proc /root /rpms /run /sbin /selinux /srv /stand /sun /SUN /sys /sysout /system /tcb /tftpboot /tmp /tools /tst /u /UNIX /usr /var /vol "
	fi
		for i in $ROOTDIRLST
		do
			if test -d $i
			then
				SYSDIR="${SYSDIR} ${i}"
			fi
		done

	cp /dev/null $DRMLOG

	dinvroom

	rm -fr ${COLDIR}/[0-9]*

	HOSTINFO=${INVDIR}/host.info
	[ -f ${HOSTINFO} ] && . ${HOSTINFO}
	if test -n "${DINVHOST}"
	then
		DINVHOSTUC=`echo $DINVHOST | dd conv=ucase 2>/dev/null`
		DINVHOSTLC=`echo $DINVHOST | dd conv=lcase 2>/dev/null`
		[ -f ${INVDIR}/${DINVHOSTUC}.hostinfo ] && . ${INVDIR}/${DINVHOSTUC}.hostinfo
		[ -f ${INVDIR}/${DINVHOSTLC}.hostinfo ] && . ${INVDIR}/${DINVHOSTLC}.hostinfo
	fi

	if test -z "$THISHOST"
	then
		THISHOST=$DINVHOST
	else
		case $THISHOST in
			[0-9]*)
				THISHOST=$DINVHOST
			;;
			*)
				SAVEHOST=$THISHOST
			;;
		esac
	fi

	THN=`echo $THISHOST | cut -d '.' -f 1`
	INVDHN=${COLDIR}/${THN}.dinv.d
	[ -d $INVDHN ] && dinvrm -rf $INVDHN

	if test -d ${INVDIR}/*.dinv.d
	then
		echo ">>> rmfr ${INVDIR}/*.dinv.d" >> $DRMLOG
		rm -fr ${INVDIR}/*.dinv.d
	fi

	if test -d ${COLDIR}/*.dinv.d
	then
		echo ">>> rmfr ${COLDIR}/*.dinv.d" >> $DRMLOG
		rm -fr ${COLDIR}/*.dinv.d
	fi

	mkdir -p $INVDHN 2>/dev/null 2>/dev/null
	if test $? -ne 0
	then
		echo ">>> create directory ($INVDHN) failed. using current directory ($PWD)"
		INVDHN=$PWD
	fi

	INVCSV=$COLDIR/dinv.csv
	INVORA=$COLDIR/dinv.ora
	INVNET=$COLDIR/dinv.net
	INVEXP=$COLDIR/dinv.exp
	INVLFS=$COLDIR/dinv.lfs
	INVNFS=$COLDIR/dinv.nfs
	INVNIZ=$COLDIR/dinv.niz		###	nics
	INVRIZ=$COLDIR/dinv.riz		###	routes
	INVPIZ=$COLDIR/dinv.piz		###	processes
	INVLIZ=$COLDIR/dinv.liz		###	listens
	INVMIZ=$COLDIR/dinv.miz		###	mounts
	INVFIZ=$COLDIR/dinv.fiz		###	filesystems
	INVIIZ=$COLDIR/dinv.iiz		###	inodes
	INVKIZ=$COLDIR/dinv.kiz		###	packages
	INVSUD=$COLDIR/dinv.sud		###	sudoers

	DENVIRON=$INVDIR/.dinvenv		# deprecated
	### [ -f $DENVIRON ] && . $DENVIRON
	LENVIRON=$INVDIR/local.dinvenv		# deprecated
	### [ -f $LENVIRON ] && . $LENVIRON

	DINVCONF=${INVDIR}/dinv.conf
	[ -f ${DINVCONF} ] && . ${DINVCONF}
	dinvrm -f $INVORA $INVNET $INVEXP $INVLFS $INVNFS $INVNIZ $INVLIZ $INVIIZ $INVMIZ $INVFIZ $INVRIZ $INVKIZ
	# purge
	dinvrm -f clup.out clup.err /root/clup.out /root/clup.err /clup.out /clup.err
	find ${INVDIR} -size 0 -type f > ${TEMPDINV}/clup.out 2> ${TEMPDINV}/clup.err
	dinvrm -f `cat ${TEMPDINV}/clup.out`
	# misc
	cd ${INVDIR}
	TWD=`date +%a`
	test -d ${TWD}.d || mkdir -p ${TWD}.d 2>/dev/null
	YWD=ontem
	test -d ${YWD}.d || mkdir -p ${YWD}.d 2>/dev/null

	ps -fe > $INVPIZ 2>&1
}

dinvinq () {
	test "$DISTATUS" = "n/a" && DISTATUS=""

	UNB=`uname -a`

	OPSYNAME=`echo $UNB | cut -d ' ' -f 1`
	OPSYVERS=`echo $UNB | cut -d ' ' -f 3`

	case $OPSYNAME in
		AIX)
			VENDORID=IBM

			TEMPFREQ=`lsdev -Cc processor | grep -i available | head -1 | cut -d ' ' -f 1  | xargs -I {} /usr/sbin/lsattr -E -l {} | grep -i "^frequency"`
			[ "$TEMPFREQ" != "" ] && PROCLOCK="`echo $TEMPFREQ | awk '{print $2}' | cut -c 1-4` MHz"

			TEMPTYPE=`lsdev -Cc processor | grep -i available | head -1 | cut -d ' ' -f 1  | xargs -I {} /usr/sbin/lsattr -E -l {} | grep -i "^type"`
			[ "$TEMPTYPE" != "" ] && PROCNAME=`echo $TEMPTYPE | awk '{print $2}'`

			TEMPMODL=`lsattr -El sys0 | grep "^modelname" | tr -s " " | cut -d ',' -f 2 | cut -d ' ' -f 1 | tr "-" "_"`
			[ "$TEMPMODL" != "" ] && MANMODEL=$TEMPMODL

			TEMPCPUS=`lsdev -Cc processor | grep -i available | wc -l | tr -d " "`
			[ "$TEMPCPUS" != "" ] && PROCOUNT=$TEMPCPUS

			TEMPRAMG=`lsattr -El mem0 | grep "^size " | tr -s " " | cut -d ' ' -f 2`
			[ "$TEMPRAMG" != "" ] && RAMSIZEG=`expr $TEMPRAMG / 1024`

			PROCARCH=`uname -p 2> .pa.err`
			test -z "$PROCARCH" && PROCARCH=unk

			OPSYRELS=`echo $UNB | cut -d ' ' -f 4`
			OPSYVERS=${OPSYRELS}.${OPSYVERS}

			TEMPSRNO=`lscfg -vp | grep -i "machine/cabinet serial" | head -1 | sed "s/.*No...//"`
			[ "$TEMPSRNO" != "" ] && HWSERIAL=$TEMPSRNO

			prtconf -L > $TEMPINFO
			grep "^LPAR Info: " $TEMPINFO > /dev/null && MACHVIRT=LPar

			OPSYLEVL=`oslevel -s > .ol.out 2> .ol.err`
			cat .ol.out .ol.err > $TEMPINFO
			if egrep -q -i -e "Usage|oslevel:" $TEMPINFO
			then
				OPSYLEVL=unk
			else
				OPSYLEVL=`cat .ol.out`
			fi
			test -z "$OPSYLEVL" && OPSYLEVL=unk
		;;
		HP-UX)
			VENDORID=HP
			PROCARCH=`uname -m`

			if [ -f /usr/contrib/bin/machinfo ]
			then
				/usr/contrib/bin/machinfo > $TEMPINFO

				ALTMEMHP=`cat $TEMPINFO | grep "^Memory = " | awk '{print $3}'`

				TEMPLINE=`cat $TEMPINFO | egrep -i -e "model string =|Model:" | grep -i -v processor`
				case $TEMPLINE in
					*SD64A*) MANMODEL=SD64A ; MACHVIRT=nPar ;;
					*SD64B*) MANMODEL=SD64B ; MACHVIRT=nPar ;;
					*Superdome2*) MANMODEL=Superdome2 ; MACHVIRT=nPar ;;
					*9000/800/*) MANMODEL=`echo $TEMPLINE | awk '{print $2}' | sed "s:9000/800/::" | tr -d '"'` ; MACHVIRT=no ;;
					*ia64\ hp\ server\ Integrity\ Virtual\ *) MANMODEL="ia64 VM" ; MACHVIRT=VM ;;
					*ia64\ hp\ server\ *) MANMODEL=`echo $TEMPLINE | sed "s/.*ia64 hp server //" | tr -d '"'` ; MACHVIRT=no ;;
					*ia64\ hp\ Integrity\ *) MANMODEL=`echo $TEMPLINE | sed "s/.*ia64 hp Integrity //" | tr -d '"'` ; MACHVIRT=no ;;
				esac

				TEMPLINE=`cat $TEMPINFO | grep -i "processor.*hz" | head -1`
				TEMPCPUS=`echo $TEMPLINE | awk '{print $1}'`
				if [ "$TEMPCPUS" = "" ]
				then
					TEMPLINE=`cat $TEMPINFO | grep -i "Number of CPUs = " | head -1`
					TEMPCPUS=`echo $TEMPLINE | awk '{print $5}'`
				fi
			else
				if [ -f /opt/ignite/bin/print_manifest ]
				then
					/opt/ignite/bin/print_manifest > $TEMPINFO 2> $TEMPERRO

					TEMPLINE=`cat $TEMPINFO | egrep -i -e "Model:" | grep -i -v processor`
					case $TEMPLINE in
						*SD64A*) MANMODEL=SD64A ; MACHVIRT=nPar ;;
						*SD64B*) MANMODEL=SD64B ; MACHVIRT=nPar ;;
						*Superdome2*) MANMODEL=Superdome2 ; MACHVIRT=nPar ;;
						*9000/800/*) MANMODEL=`echo $TEMPLINE | awk '{print $2}' | sed "s:9000/800/::" | tr -d '"'` ; MACHVIRT=no ;;
						*ia64\ hp\ server\ Integrity\ Virtual\ *) MANMODEL="ia64 VM" ; MACHVIRT=VM ;;
						*ia64\ hp\ server\ *) MANMODEL=`echo $TEMPLINE | sed "s/.*ia64 hp server //" | tr -d '"'` ; MACHVIRT=no ;;
						*ia64\ hp\ Integrity\ *) MANMODEL=`echo $TEMPLINE | sed "s/.*ia64 hp Integrity //" | tr -d '"'` ; MACHVIRT=no ;;
					esac

					TEMPLINE=`cat $TEMPINFO | grep "Processors:" | head -1`
					TEMPCPUS=`echo $TEMPLINE | awk '{print $2}'`
				fi
			fi
			[ "$MANMODEL" = "n/a" ] && MANMODEL=`model`
			if [ "$TEMPCPUS" != "" ]
			then
				if expr $TEMPCPUS : "[a-z,A-Z]" > /dev/null
				then
					TEMPLINE=`ioscan -fnC processor | grep PROCESSOR | wc -l`
					TEMPCPUS=`echo $TEMPLINE`
				fi
				PROCOUNT=$TEMPCPUS
				TEMPLINE=`cat $TEMPINFO | grep -i "processor.*hz" | head -1`
				case "$TEMPLINE" in
					*PA-RISC*) PROCNAME=`echo $TEMPLINE | awk '{print $2,$3}'` ;;
					*Itanium\(R\)*Processor*[0-9]*) PROCNAME=`echo $TEMPLINE | sed "s/(R)//g" | awk '{print $2,$4}'` ;;
					*Itanium\(R\)*) PROCNAME=`echo $TEMPLINE | sed "s/(R)//g" | awk '{print $3,$5}'` ;;
					*Itanium\ 2*) PROCNAME=`echo $TEMPLINE | awk '{print $3,$4,$5}'` ;;
				esac
				if [ "$PROCNAME" = "n/a" ]
				then
					TEMPLINE=`cat $TEMPINFO | grep -i "processor model:" | head -1`
					if [ "$TEMPLINE" != "" ]
					then
						PROCNAME=`echo $TEMPLINE | awk '{print $5,$6,$7}'`
					else
						PROCNAME=PA-RISC
					fi
				fi
			fi
			TEMPLINE=`cat $TEMPINFO | grep -i "hz" | head -1`
			if [ "$TEMPLINE" != "" ]
			then
				case "$TEMPLINE" in
					*[pP]rocessor*\ \([0-9]*\ [MG]Hz*) PROCLOCK=`echo $TEMPLINE | cut -d ',' -f 1 | sed "s/.* (//"` ;;
					*[sS]peed:\ [0-9]*\ [MG]Hz*) PROCLOCK=`echo $TEMPLINE | awk '{print $3,$4}'` ;;
					*[sS]peed\ =\ [0-9]*\ [MG]Hz*) PROCLOCK=`echo $TEMPLINE | awk '{print $4,$5}'` ;;
				esac
			fi

			swapinfo > $TEMPSWAP 2> /dev/null
			TEMPRAMG=`grep "^memory" $TEMPSWAP | tr -s " " | cut -d ' ' -f 2`
			[ "$TEMPRAMG" != "" ] && RAMSIZEG=`expr $TEMPRAMG / 1048576`
			[ "$TEMPRAMG" = "" ] && [ -n "$ALTMEMHP" ] && RAMSIZEG=`expr $ALTMEMHP / 1024`

			if [ $OPSYVERS = "B.11.00" ]
			then
				TEMPSRNO=`cat $TEMPINFO | grep "Serial number:" | awk '{print $3}'`
			else
				TEMPSRNO=`getconf MACHINE_SERIAL 2> /dev/null`
			fi
			[ "$TEMPSRNO" != "" ] && HWSERIAL=$TEMPSRNO

			if [ -x /usr/sbin/vparstatus ]
			then
				MACHVIRT=vPar
				/usr/sbin/vparstatus > $TEMPINFO 2> $TEMPERRO
			else
				if [ -x /opt/hpvm/bin/hpvminfo ]
				then
					MACHVIRT=HPVM
					/opt/hpvm/bin/hpvminfo > $TEMPINFO
					grep -i "Not on an" $TEMPINFO > /dev/null 2>&1 && MACHVIRT=nPar
					grep -i "Running on an HPVM host" $TEMPINFO > /dev/null 2>&1 && MACHVIRT=HPVM-host
					grep -i "Running inside an HPVM guest" $TEMPINFO > /dev/null 2>&1 && MACHVIRT=HPVM-guest
				fi
			fi

			if test "$MACHVIRT" = "HPVM-host"
			then
				test -x /opt/hpvm/bin/hpvmstatus && /opt/hpvm/bin/hpvmstatus > .hvs.out 2>&1
				cat .hvs.out | egrep -v -e "^\[Virtual |^Virtual |^========" | awk '{print $1}' > .vgl
				TEMPGLST=`( cat .vgl | tr "\n" "," ; echo ) | sed "s/,$//"`
				test -n "$TEMPGLST" && VPGUESTS="$TEMPGLST"
			fi

			OPSYLEVL=`swlist | grep "HP-UX .* Operating Environment" | awk '{print $2}' | sort -r | head -1`
			[ "$OPSYLEVL" = "" ] && OPSYLEVL=N/A
		;;
		Linux)
			TEMPLINE=`cat /proc/cpuinfo | grep -i "model name" | sort -u | cut -d ':' -f 2 | tr -s " " | sed "s/^ *//"`
			[ "$TEMPLINE" != "" ] && PROCNAME="$TEMPLINE"
			echo $PROCNAME > ${TEMPDINV}/.pn.out
			if grep -q "@" ${TEMPDINV}/.pn.out
			then
				PROCNAME=`echo $PROCNAME | cut -d '@' -f 1 | sed "s/ *$//"`
			fi

			PROCLOCK=0
			TEMPCLOK=`cat /proc/cpuinfo | grep -i "cpu mhz" | sort -u | cut -d ':' -f 2 | cut -d '.' -f 1`
			echo "$TEMPCLOK" > $TEMPMISC
			if [ -s $TEMPMISC ]
			then
				TEMPLINS=`cat $TEMPMISC | wc -l`
				if [ $TEMPLINS -eq 1 ]
				then
					[ "$TEMPCLOK" != "" ] && PROCLOCK="$TEMPCLOK MHz"
				else
					TEMPCLOK=`cat $TEMPMISC | awk '{s+=$1}END{print s}'`
					TEMPCLOK=`expr $TEMPCLOK / $TEMPLINS`
					PROCLOCK="$TEMPCLOK MHz"
				fi
			else
				PROCLOCK="many MHz"
			fi
			[ "$PROCLOCK" = "0" ] && PROCLOCK="few MHz"

			TEMPCPUS=`cat /proc/cpuinfo | grep -i "physical id" | sort -u | wc -l`
			TEMPCORE=`cat /proc/cpuinfo | grep -i "cpu cores" | sort -u | cut -d ':' -f 2 | tr -d " "`
			if [ $TEMPCPUS -eq 0 -o "$TEMPCORE" = "" ]
			then
				TEMPCPUS=`cat /proc/cpuinfo | grep "^processor" | wc -l`
				[ "$TEMPCPUS" != "" ] && PROCOUNT=$TEMPCPUS
			else
				TEMPLINE=`expr $TEMPCPUS \* $TEMPCORE`
				[ "$TEMPLINE" != "" ] && [ $TEMPLINE -gt 0 ] && PROCOUNT="$TEMPLINE"
			fi

			TEMPRAMG=`cat /proc/meminfo | grep "^MemTotal:" | tr -s " " | cut -d ' ' -f 2`
			[ "$TEMPRAMG" != "" ] && RAMSIZEG=`expr $TEMPRAMG / 1048576`

			free > $TEMPFREE 2> /dev/null
			TEMPSWAP=`grep "^Swap:" $TEMPFREE | tr -s " " | cut -d ' ' -f 2`
			[ "$TEMPSWAP" != "" ] && SWAPSIZE=`expr 1 + \( $TEMPSWAP / 1048576 \)`

			uname -p > ${TEMPDINV}/tt.aa 2> ${TEMPDINV}/tt.ae
			if test -s ${TEMPDINV}/tt.aa
			then
				PROCARCH=`cat ${TEMPDINV}/tt.aa`
			else
				PROCARCH=unknown
			fi

			OPSYVERS=`echo $UNB | cut -d ' ' -f 3 | cut -d '-' -f 1`
			if test -s /etc/SuSE-release
			then
				TEMPVERS=`cat /etc/SuSE-release 2> /dev/null | grep "VERSION = " | awk '{print $3}'`
				TEMPATCH=`cat /etc/SuSE-release 2> /dev/null | grep "PATCHLEVEL = " | awk '{print $3}'`
				TEMPDIST=`cat /etc/SuSE-release 2> /dev/null | head -1`
			elif test -s /etc/os-release
			then
				TEMPDIST=`grep "^NAME=" /etc/os-release 2> /dev/null | head -1 | cut -d '=' -f 2 | tr -d '"' | cut -d ' ' -f 1`
				TEMPVERS=`grep "^VERSION=" /etc/os-release 2> /dev/null | head -1 | cut -d '=' -f 2 | tr -d '"' | cut -d ' ' -f 1`
			else
				TEMPVERS=`cat /etc/*elease* 2> /dev/null | grep -i release | grep -v "^#" | tail -1`
				TEMPDIST=`echo $TEMPVERS | sed "s/release.*$//"`
			fi
			case $TEMPDIST in
				SUSE\ Linux\ Enterprise\ Server*)
					TEMPDIST=SLES
					TEMPRELE="${TEMPVERS}.${TEMPATCH}"
				;;
				Red\ Hat\ Enterprise\ Linux*)
					TEMPDIST=RHEL
					TEMPRELE=`echo $TEMPVERS | sed "s/.*release //" | awk '{print $1}'`
				;;
				Oracle\ Linux\ Server*)
					TEMPDIST=OLS
					TEMPRELE=`echo $TEMPVERS | sed "s/.*release //" | awk '{print $1}'`
				;;
				Oracle\ VM\ server*)
					TEMPDIST=OVS
					TEMPRELE=`echo $TEMPVERS | sed "s/.*release //" | awk '{print $1}'`
				;;
				Enterprise\ Linux*)
					TEMPDIST=RHEL
					TEMPRELE=`echo $TEMPVERS | sed "s/.*release //" | awk '{print $1}'`
				;;
				Mandriva\ Linux\ Corporate\ Server*)
					TEMPDIST=Mandriva_CS
					TEMPRELE=`echo $TEMPVERS | sed "s/.*Server//" | awk '{print $1}'`
				;;
				openSUSE)
					TEMPDIST=openSUSE
					TEMPRELE=$TEMPVERS
				;;
				CentOS)
					TEMPDIST=CentOS
					TEMPRELE=$TEMPVERS
				;;
				Ubuntu)
					TEMPDIST=Ubuntu
					TEMPRELE=$TEMPVERS
				;;
				*)
					TEMPRELE=`echo $TEMPVERS | sed "s/.*release //" | awk '{print $1}'`
				;;
			esac
			if test -s /etc/debian_version
			then
				if test -s /etc/lsb-release
				then
					TEMPDIST=`grep DISTRIB_ID /etc/lsb-release | cut -d '=' -f 2`
					TEMPRELE=`grep DISTRIB_RELEASE /etc/lsb-release | cut -d '=' -f 2`
				else
					TEMPDIST=Debian
					TEMPRELE=`cat /etc/debian_version`
				fi
			fi
			[ "$TEMPDIST" != "" ] && [ "$TEMPRELE" != "" ] && OPSYVERS="${TEMPDIST} ${TEMPRELE}"

			if test -x /usr/sbin/dmidecode -a $IAMGROOT = 1
			then
				/usr/sbin/dmidecode > $TEMPINFO
				grep -i "product.*name.*vmware" $TEMPINFO > /dev/null && MACHVIRT=VMware
				grep -i "domu" $TEMPINFO > /dev/null && MACHVIRT=Xen
				TEMPLINE=`egrep -i -e "product name:|product:" $TEMPINFO | head -1 | cut -d ':' -f 2 | tr -s " "`
				case $TEMPLINE in
					*PowerEdge*) VENDORID=Dell ; MANMODEL="$TEMPLINE" ;;
					*ProLiant*|*Deskpro*) VENDORID=HP ; MANMODEL="$TEMPLINE" ;;
					*domU*) VENDORID=Xen ; MANMODEL="$TEMPLINE" ;;
					*PRIMEQUEST*) VENDORID=Fujitsu ; MANMODEL="$TEMPLINE" ;;
					*SUN*) VENDORID=Sun ; MANMODEL=`echo $TEMPLINE | sed "s/ *SUN *//" | sed "s/ *SERVER *//"` ;;
					*VMware*) VENDORID=VMware ; MANMODEL=`echo $TEMPLINE | sed "s/VMware //" ` ;;
					*ORACLE*) VENDORID=Oracle ; MANMODEL=`echo $TEMPLINE | sed "s/ *ORACLE *//" | sed "s/ *SERVER *//"` ;;
					*System*) VENDORID=IBM ; MANMODEL="$TEMPLINE" ;;
					*) MANMODEL="$TEMPLINE" ;;
				esac
				SAVMODEL="$MANMODEL"
				TEMPLINE=`egrep -e "Exadata |Exalogic " $TEMPINFO | sort -u | tail -1 | tr "\t" " " | tr -s " " | sed "s/^ *//"`
				if test -n "$TEMPLINE"
				then
					case $TEMPLINE in
						*Exadata*|*Exalogic*) MANMODEL="$TEMPLINE" ;;
						*) MANMODEL="$SAVMODEL" ;;
					esac
				fi
			else
				VENDORID=Generic
				MANMODEL=Generic
			fi

			if [ "$VENDORID" = "n/a" ]
			then
				TEMPLINE=`egrep -i -e "manufacturer:" $TEMPINFO | head -1 | cut -d ':' -f 2 | tr -s " "`
				[ "$TEMPLINE" != "" ] && VENDORID=$TEMPLINE
			fi

			if [ -x /usr/sbin/dmidecode -a $IAMGROOT = 1 ]
			then
				TEMPSRNO=`dmidecode -t system 2> /dev/null | grep -i serial | head -1 | cut -d ':' -f 2 | tr -d " "`
				if [ "$TEMPSRNO" != "" ]
				then
					HWSERIAL=$TEMPSRNO
				else
					TEMPSRNO=`dmidecode | grep -i serial | tail -1 | cut -d ':' -f 2 | tr -d " "`
					if [ "$TEMPSRNO" != "" ]
					then
						HWSERIAL=$TEMPSRNO
					else
						HWSERIAL=unknown
					fi
				fi
			else
				HWSERIAL=unknown
			fi

			OPSYLEVL=`uname -r`
		;;
		SunOS)
			TEMPSWAP=0
			/usr/sbin/swap -l | grep -i -v swapfile | awk '{print $4}' | while read swapblocks
			do
				TEMPSWAP=`expr $TEMPSWAP + $swapblocks`
			done
			[ $TEMPSWAP -gt 0 ] && SWAPSIZE=`expr $TEMPSWAP / 2097152`

			### FIXME: there can be only one (psrinfo)
			TEMPCLOK=`psrinfo -v | grep -i hz | head -1 | tr -s ' ' | cut -d ' ' -f 7`
			[ "$TEMPCLOK" != "" ] && PROCLOCK="$TEMPCLOK MHz"

			/usr/sbin/prtconf | grep "^SUNW," | cut -d ',' -f 2 > $TEMPINFO
			if test -s $TEMPINFO
			then
				MANMODEL=`cat $TEMPINFO`
			else
				/usr/sbin/prtdiag | grep "^System Configuration:" | cut -d ':' -f 2 > $TEMPINFO
				if test -s $TEMPINFO
				then
					MANMODEL=`cat $TEMPINFO | sed "s/ *Sun Microsystems *//"`
				fi
			fi

			if test -x /usr/bin/kstat
			then
				TEMPLINE=`/usr/bin/kstat -m cpu_info | grep brand | sed "s/brand//" | sort -u | tr -d "\t" | sed "s/ *//"`

				if test "${TEMPLINE}" = "(unsupported)"
				then
					TEMPLINE=`/usr/bin/kstat -m cpu_info | grep cpu_type | sed "s/cpu_type//" | sort -u | tr -d "\t" | sed "s/ *//"`
					if test "`echo $TEMPLINE | cut -c 1-5`" = "sparc"
					then
						TEMPLINE=`/usr/sbin/prtconf -vp |grep -i sparc |grep compatible:|sort -u|cut -d ':' -f 2 | sed "s/ *//"|tr -d " '"|tr "\n" "+"`
					fi
				fi
			elif test -x /usr/sbin/prtconf
			then
				TEMPLINE=`/usr/sbin/prtconf | grep -i sparc | sort -u | awk '{print $1}' | sed "s/ *//"`
			else
				TEMPLINE=`psrinfo -v | grep -i hz | head -1 | tr -s ' ' | cut -d ' ' -f 3`
			fi

			[ "$TEMPLINE" != "" ] && PROCNAME=$TEMPLINE

			case $PROCNAME in
				*[Ss][Pp][Aa][Rr][Cc]*) VENDORID=Sun ;;
				*[Ii][Nn][Tt][Ee][Ll]*)
					VENDORID=Gen_Intel
					PROCNAME=`echo $PROCNAME | cut -d '@' -f 1`
				;;
				*86*) VENDORID=Gen_x86 ;;
				*) VENDORID=Other ;;
			esac

			TEMPCPUS=`psrinfo | wc -l | tr -d " "`
			[ "$TEMPCPUS" != "" ] && PROCOUNT=$TEMPCPUS

			TEMPRAMG=`prtconf | grep "^Memory size:" | cut -d ' ' -f 3`
			[ "$TEMPRAMG" != "" ] && RAMSIZEG=`expr $TEMPRAMG / 1024`

			PROCARCH=`uname -p`

			TEMPSRNO=`prtconf -vp | grep -i "ChassisSerialNumber" | head -1 | sed "s/.*ChassisSerialNumber //" | awk '{print $1}' | tr "-" "_"`
			if [ "$TEMPSRNO" != "" ]
			then
				HWSERIAL=$TEMPSRNO
			else
				if [ -f /usr/sbin/sneep ]
				then
					TEMPSRNO=`/usr/sbin/sneep | tr "-" "_"`
					[ "$TEMPSRNO" != "" ] && HWSERIAL=$TEMPSRNO
				fi
			fi

			OPSYLEVL=`uname -v`
			test "$OPSYLEVL" = "Generic_Virtual" && MACHVIRT=zone

			if test -x /usr/sbin/zoneadm
			then
				/usr/sbin/zoneadm list > .zal.out 2>&1
				zalk=`cat .zal.out | wc -l`
				if test "$zalk" -gt 1
				then
					MACHVIRT=global
					TEMPGLST=`( cat .zal.out | grep -v global | tr "\n" "," ; echo ) | sed "s/,$//"`
					test -n "$TEMPGLST" && VPGUESTS="$TEMPGLST"
				fi
			fi
		;;
	esac

	case $PROCLOCK in
		*\ MHz) PROCLOCK=`echo $PROCLOCK | sed "s/ MHz//"` ;;
		*\ GHz)
			PROCLOCK=`echo $PROCLOCK | sed "s/ GHz//"`
			PROCLOCK=`echo "$PROCLOCK * 1000" | bc | cut -d '.' -f 1`
		;;
	esac

	TMPOUT=`uptime`
	TMPUPTIM=`echo $TMPOUT | cut -d ',' -f 1 | sed "s/.*up //" | sed "s/(s)/s/" | sed "s/ days//"`
	[ "$TMPUPTIM" != "" ] && HCUPTIME=$TMPUPTIM

	UTLOAD=`echo $TMPOUT | awk -F":" '{print $NF}'`

	if [ "${DINVHOST}" = "n/a" ]
	then
		DINVHOST=`echo $UNB | cut -d ' ' -f 2`
		TEMPHOST=`echo $DINVHOST | cut -d '.' -f 1`
		# TEMPHOST=$DINVHOST
		if [ "$TEMPHOST" != "" ]
		then
			DINVHOST=$TEMPHOST
		else
			DINVHOST=$THISHOST
		fi
	fi

	#________________________________________________________________
	#

	if [ -n "${LONGDESC}" ]
	then
		if [ "${DCOMMENT}" = "n/a" ]
		then
			DCOMMENT="${LONGDESC}"
		else
			DCOMMENT="${DCOMMENT} + ${LONGDESC}"
		fi
	fi

	if [ -n "${VMINFORM}" ]
	then
		if [ "${DCOMMENT}" = "n/a" ]
		then
			DCOMMENT="${VMINFORM}"
		else
			DCOMMENT="${DCOMMENT} + ${VMINFORM}"
		fi
	fi

	[ -z "${QUIKDESC}" ] || HOSTDESC="${QUIKDESC}"

	[ -z "${TAGSDESC}" ] || DINVTAGS="${TAGSDESC}"

	#________________________________________________________________
	#

	DINVHONA=$THISHOST
	test -z "$DINVHONA" && DINVHONA=`uname -n`
	test -z "$DINVHONA" && DINVHONA=unknown
	TESTHOST=$DINVHOST

	#________________________________________________________________
	#

	if [ -z "${TZ}" ]
	then
		ELT=/etc/localtime
		if [ -h ${ELT} ]
		then
			DINVTIZO=`ls -l ${ELT} | awk -F '/' '{print $NF}'`
		elif [ -f ${ELT} ]
		then
			DINVTIZO=localtime
		fi
		[ -z "${DINVTIZO}" ] && DINVTIZO=unknown
	else
		DINVTIZO=${TZ}
	fi

	#_______________________________ 
	#                               #
	#	begin	net		#
	#_______________________________#
	#

	if [ -f /etc/resolv.conf ]
	then
		DNSERVER=`cat /etc/resolv.conf | grep -v "^#" | sed "s/ *//" | grep -i "^nameserver" | awk '{print $2}' | tr "\n" ","`
		DNSERVER=`echo $DNSERVER | sed 's/,$//'`
	else
		if type nslookup > /dev/null 2>&1
		then
			DNSERVER=`nslookup $TESTHOST | grep -i "Address:" | head -1 | awk '{print $2}' | tr -d " \t"`
		fi
	fi
	[ "$DNSERVER" = "" ] && DNSERVER=unknown

	#________________________________________________________________
	#

	TEMPADDR=`grep -i "[ 	]$TESTHOST[ 	]" /etc/hosts | grep -v "^#" | grep -v "127\.0"`
	[ "$TEMPADDR" = "" ] && TEMPADDR=`grep -i "[ 	]$TESTHOST$" /etc/hosts | grep -v "^#" | grep -v "127\.0"`
	HOSTADDR=`echo $TEMPADDR | tr "\t" " " | tr -s " " | cut -d ' ' -f 1`
	if [ "$HOSTADDR" != "" -o "$OPSYNAME" != "HP-UX" ]
	then
		IPV4ADDR=$HOSTADDR
	else
		type nslookup > ${TEMPDINV}/nslu.out 2> ${TEMPDINV}/nslu.err
		if test -s ${TEMPDINV}/nslu.out
		then
			IPV4ADDR=`nslookup $TESTHOST | egrep -i -e "Address:|Addresses:" | grep -v "#53" | tail -1 | awk '{print $2}'`
			if [ "$IPV4ADDR" = "$DNSERVER" ]
			then
				IPV4ADDR=unknown
			fi
		else
			IPV4ADDR=nolookup
		fi
	fi

	if [ "$IPV4ADDR" = "" -o "$IPV4ADDR" = "127.0.0.1" -o "$IPV4ADDR" = "127.0.1.1" -o "$IPV4ADDR" = "nolookup" -o "$IPV4ADDR" = "unknown" ]
	then
		if type nslookup > /dev/null 2>&1
		then
			IPV4ADDR=`nslookup $DINVHONA | egrep -i -e "Address:|Addresses:" | grep -v "#53" | tail -1 | awk '{print $2}'`
		else
			if type getent > /dev/null 2>&1
			then
				IPV4ADDR=`getent hosts $TESTHOST | grep -v "127\.0" | awk '{print $1}'`
			fi
		fi
	fi

	test "`isipv4 ${IPV4ADDR}`" != "yes" && IPV4ADDR=unknown

	if [ "$IPV4ADDR" = "" -o "$IPV4ADDR" = "127.0.0.1" -o "$IPV4ADDR" = "127.0.1.1" -o "$IPV4ADDR" = "nolookup" -o "$IPV4ADDR" = "unknown" ]
	then
		test -s ${INVDIR}/${TESTHOST}.addr && IPV4ADDR=`cat ${INVDIR}/${TESTHOST}.addr`
	fi

	#________________________________________________________________
	#

	case $OPSYNAME in

		AIX)
			DGATEWAY=`netstat -rn | grep "^default" | tail -1 | awk '{print $2}'`

			DINVNICS=`( ifconfig -a | grep ' flags=' | egrep -ive "lo0" | sort | cut -d ':' -f 1 | tr "\n" "," ; echo ) | sed "s/,$//"`

			for i in `echo $DINVNICS | tr "," " "`
			do
				TEMPIPAS="${TEMPIPAS},`lsattr -l $i -a netaddr -F value`"
			done
			DINVIPAS=`echo $TEMPIPAS | sed "s/^,//"`

			for i in `echo $DINVNICS | tr "," " "`
			do
				XNIC=`echo $i | sed "s/en/ent/"`
				XMAC=`lscfg -vpl ${XNIC} | grep "Network Address" | tr "." " " | awk '{print $3}'`
				TEMPMACS="${TEMPMACS},$XMAC"
				TEMPMASK="${TEMPMASK},`lsattr -l $i -a netmask -F value`"
			done
			DINVMACS=`echo $TEMPMACS | sed "s/^,//"`
			DINMASKS=`echo $TEMPMASK | sed "s/^,//"`
		;;

		HP-UX)
			DGATEWAY=`netstat -rn | grep "^default" | tail -1 | awk '{print $2}'`

			if [ $OPSYVERS = "B.11.23" -o $OPSYVERS = "B.11.31" ]
			then
				DINVNICS=`( netstat -win | egrep -ive "lo0|name" | sort | awk '{print $1}' | tr "\n" "," ; echo ) | sed "s/,$//"`
			else
				DINVNICS=`( netstat -in | egrep -ive "lo0|name" | sort | awk '{print $1}' | tr "\n" "," ; echo ) | sed "s/,$//"`
			fi

			DINVIPAS=`( netstat -in | egrep -ive "lo0|name" | sort | awk '{print $4}' | tr "\n" "," ; echo ) | sed "s/,$//"`

			lanscan -i -a > ${TEMPDINV}/ll.ss
			for i in `echo $DINVNICS | tr "," " " | tr -d "*"`
			do
				XMAC=`grep " ${i} " ${TEMPDINV}/ll.ss | awk '{print $1}' | sed "s/^0x//"`
				TEMPMACS="${TEMPMACS},$XMAC"
				TMSK=`ifconfig ${i} | grep " netmask " | awk '{print $4}'`
				XMSK=`xia2dia ${TMSK}`
				TEMPMSKS="${TEMPMSKS},$XMSK"
			done
			DINVMACS=`echo $TEMPMACS | sed "s/^,//"`
			DINMASKS=`echo $TEMPMSKS | sed "s/^,//"`
		;;

		Linux)
			if type netstat > /dev/null 2>&1
			then
				DGATEWAY=`netstat -rn | grep "^0.0.0.0" | tail -1 | awk '{print $2}'`
			else
				DGATEWAY=`ip route | grep "^default via " | awk '{print $3}'`
			fi
			ip addr > ${TEMPDINV}/ii.cc 2> ${TEMPDINV}/ii.ee
			if [ $? -eq 0 -a -s ${TEMPDINV}/ii.cc ]
			then
				> ${TEMPLINKLIST}
				> ${TEMPADDRLIST}
				> ${TEMPMASKLIST}
				> ${TEMPMACALIST}
				cat ${TEMPDINV}/ii.cc | grep "inet " | awk '{print $2,$NF}' > ${TEMPWORKLIST}

				while read ipmask nicnam
				do
					test -z "${pastefmt}" && pastefmt=- || pastefmt="${pastefmt} -"
					echo $nicnam >> ${TEMPLINKLIST}
					echo $ipmask | cut -d '/' -f 1 >> ${TEMPADDRLIST}
					echo $ipmask | cut -d '/' -f 2 >> ${TEMPMASKLIST}
					ip addr show dev $nicnam | egrep -e "link/" | awk '{print $2}' | tr -d ":" >> ${TEMPMACALIST}
				done < ${TEMPWORKLIST}

				NICZ=`paste -d "," ${pastefmt} < ${TEMPLINKLIST}`
				IP4Z=`paste -d "," ${pastefmt} < ${TEMPADDRLIST}`
				MSKZ=`paste -d "," ${pastefmt} < ${TEMPMASKLIST}`
				MACZ=`paste -d "," ${pastefmt} < ${TEMPMACALIST}`

				DINVNICS=${NICZ}
				DINVIPAS=${IP4Z}
				DINMASKS=${MSKZ}
				DINVMACS=${MACZ}
			else
				ifconfig > ${TEMPDINV}/ii.cc 2> ${TEMPDINV}/ii.ee
				while read xlin
				do
					[ "$xlin" = "" ] && continue
					set $xlin
					if [ "$2" = "Link" -a "$4" = "HWaddr" ]
					then
						XNIC=$1
						XMAC=`echo $5 | tr -d ":"`
						read xdet
						set `echo $xdet | tr ":" " "`
						if [ "$1$2" = "inetaddr" -a "$6" = "Mask" ]
						then
							XIPA=$3
							XMSK=$7
							TEMPNICS="${TEMPNICS},$XNIC"
							TEMPMACS="${TEMPMACS},$XMAC"
							TEMPIPAS="${TEMPIPAS},$XIPA"
							TEMPMSKS="${TEMPMSKS},$XMSK"
						fi
	        			else
	                			ccc=`echo "${xlin}" | grep ": "`
	                			if [ "${ccc}" != "" ]
	                			then
	                        			XNIC=`echo ${xlin} | cut -d ':' -f 1`
	                        			[ "${XNIC}" = "lo" ] && continue
	                        			XIPA=N/A
	                        			XMSK=N/A
	                        			while read xdet
	                        			do
	                                			[ "$xdet" = "" ] && continue
	                                			set $xdet
	                                			if [ "$1" = "inet" -a "$3" = "netmask" ]
	                                			then
	                                        			XIPA=$2
	                                        			XMSK=$4
	                                			elif [ "$1" = "ether" ]
	                                			then
									XMAC=`echo $2 | tr -d ":"`
	                                        			if [ "${XIPA}" != "N/A" ]
	                                        			then
										TEMPNICS="${TEMPNICS},$XNIC"
										TEMPMACS="${TEMPMACS},$XMAC"
										TEMPIPAS="${TEMPIPAS},$XIPA"
										TEMPMSKS="${TEMPMSKS},$XMSK"
	                                        			fi
	                                        			break
	                                			fi
	                        			done
	                			fi
					fi
				done < ${TEMPDINV}/ii.cc
				DINVNICS=`echo $TEMPNICS | sed "s/^,//"`
				DINVMACS=`echo $TEMPMACS | sed "s/^,//"`
				DINVIPAS=`echo $TEMPIPAS | sed "s/^,//"`
				DINMASKS=`echo $TEMPMSKS | sed "s/^,//"`
			fi
		;;

		SunOS)
			DGATEWAY=`netstat -rn | grep "^default" | tail -1 | awk '{print $2}'`

			DINVNICS=`( netstat -in | tr -s "\n" | egrep -ive "lo0|name" | sort | awk '{print $1}' | tr "\n" "," ; echo ) | sed "s/,$//"`

			DINVIPAS=`( netstat -in | tr -s "\n" | egrep -ive "lo0|name" | sort | awk '{print $4}' | tr "\n" "," ; echo ) | sed "s/,$//"`

			for i in `echo $DINVNICS | tr "," " "`
			do
				ifconfig ${i} > ${TEMPDINV}/ll.ss
				XMAC=`grep "ether " ${TEMPDINV}/ll.ss | awk '{print $2}' | tr -d ":"`
				TEMPMACS="${TEMPMACS},$XMAC"
				if egrep -e '-->' ${TEMPDINV}/ll.ss >/dev/null 2>&1
				then
					TMSK=`cat ${TEMPDINV}/ll.ss | grep " netmask " | awk '{print $6}'`
				else
					TMSK=`cat ${TEMPDINV}/ll.ss | grep " netmask " | awk '{print $4}'`
				fi
				XMSK=`xia2dia ${TMSK}`
				TEMPMSKS="${TEMPMSKS},$XMSK"
			done
			DINVMACS=`echo $TEMPMACS | sed "s/^,//"`
			DINMASKS=`echo $TEMPMSKS | sed "s/^,//"`
		;;

		*)
			DGATEWAY=unk
		;;

	esac

	if [ "$IPV4ADDR" = "nolookup" ]
	then
		if [ "$DINVIPAS" = "" ]
		then
			IPV4ADDR=unknown
		else
			IPV4ADDR=`echo $DINVIPAS | cut -d ',' -f 1 | tr -d " \t"`
			[ "$IPV4ADDR" = "" ] && IPV4ADDR=$DINVIPAS
		fi
	fi

	#________________________________________________________________
	#

	> $TMPNET
	echo ${DINVNICS} >> $TMPNET
	echo ${DINVIPAS} >> $TMPNET
	echo ${DINMASKS} >> $TMPNET
	echo ${DINVMACS} >> $TMPNET
	NETCNT=`cat $TMPNET | awk '{print NF}' FS=',' | head -1`
	> $INVNET
	i=1 ; while [ $i -le $NETCNT ]
	do
		echo "${TESTHOST};"`cat $TMPNET | cut -d ',' -f $i | tr "\n" ";"` | sed "s/;$//" >> $INVNET
		i=`expr $i + 1`
	done

	if type netstat >/dev/null 2>&1
	then
		netstat -rn | sed "s/^/${DINHVOST};/" > $INVRIZ
	fi

	test -s $INVDIR/hostnicz.sh && sh $INVDIR/hostnicz.sh > $INVNIZ

	test -s $INVDIR/listeninfo.sh && sh $INVDIR/listeninfo.sh > $INVLIZ

	test -s $INVDIR/mountinfo.sh && sh $INVDIR/mountinfo.sh > $INVMIZ

	test -s $INVDIR/fsinfo.sh && sh $INVDIR/fsinfo.sh > $INVFIZ

	test -s $INVDIR/inodeinfo.sh && sh $INVDIR/inodeinfo.sh > $INVIIZ

	test -s $INVDIR/classinfo.sh && HOSTCLAS=`sh $INVDIR/classinfo.sh $DGATEWAY`

	test -s $INVDIR/runsinfo.sh && TEMPRUNS=`sh $INVDIR/runsinfo.sh | cut -d ';' -f 2`

	test -s $INVDIR/packageinfo.sh && sh $INVDIR/packageinfo.sh > $INVKIZ

	test -s $INVDIR/recoinfo.sh && sh $INVDIR/recoinfo.sh

	if test -n "$TEMPRUNS"
	then
		if test "$DINVRUNS" = "n/a"
		then
			DINVRUNS="$TEMPRUNS"
		else
			DINVRUNS="$DINVRUNS,$TEMPRUNS"
		fi
	fi

	test -s $INVDIR/patchinfo.sh && TRYPATCH=`sh $INVDIR/patchinfo.sh | cut -d ';' -f 2`

	if test -n "$TRYPATCH"
	then
		PATCHDAY="$TRYPATCH"
	fi

	#________________________________________________________________
	#

		if test "$DINVVLAN" = "n/a" -o -z "$DINVVLAN"
		then
			test -n "$VMVLANID" && DINVVLAN="$VMVLANID"
		fi

	#________________________________________________________________
	#

	if test -x $INVDIR/xsudo.sh
	then
		dinvrm -fr $INVDIR/xsudo.d
		sh $INVDIR/xsudo.sh --collect
		if test -d /tmp/xsudo.d
		then
			dinvrm -fr $INVSUD
			mv /tmp/xsudo.d $INVSUD
		fi
	fi

	#_______________________________ 
	#                               #
	#	e_n_d	net		#
	#_______________________________#
	#

	crontab -l | grep -v "^#" > $TEMPCRON
	if grep "/UNIX/PERFORMANCE/CK_ONLINE/check_online.sh" $TEMPCRON > /dev/null 2>&1
	then
		DINVPERF=true
	else
		DINVPERF=false
	fi

	#_______________________________ 
	#                               #
	#	begin	disk		#
	#_______________________________#
	#

	det=-t
	case $OPSYNAME in

		AIX)
			case $det in
				-q)
					dskcmd="lsvg|xargs lsvg|grep 'TOTAL PPs:'|awk '{print \$7}'|tr -d '('"
				;;
				-t)
					DINVDISK=`lsvg|xargs lsvg|grep 'TOTAL PPs:'|awk '{print \$7}'|tr -d '('|awk 'OFMT = "%.15g" {s+=$1}END{print s}'`
					DINVDISK=`expr $DINVDISK / 1024`
				;;
				-d)
					dskcmd="cd ${TEMPDINV};lsvg>xx.yy;lsvg|xargs lsvg|grep 'TOTAL PPs:'|awk '{print \$7}'|tr -d '('>xx.zz;paste -d ' ' xx.yy xx.zz"
				;;
				*)
					DINVDISK=0
				;;
			esac
		;;

		HP-UX)
			case $det in
				-q)
					dskcmd="cd ${TEMPDINV};vgdisplay>xx.yy;grep 'PE Size' xx.yy>xx.bb;grep 'Total PE' xx.yy>xx.cc;paste -d ' ' xx.bb xx.cc|tr -s ' '|cut -d ' ' -f 4,7|awk 'OFMT = \"%.18g\" {print \$1 * \$2}'"
				;;
				-t)
					DINVDISK=`cd ${TEMPDINV};vgdisplay>xx.yy;grep 'PE Size' xx.yy>xx.bb;grep 'Total PE' xx.yy>xx.cc;paste -d ' ' xx.bb xx.cc|tr -s ' '|cut -d ' ' -f 4,7|awk 'OFMT = "%.18g" {print \$1 * \$2}'|awk 'OFMT = "%.15g" {s+=$1}END{print s}'`
					DINVDISK=`expr $DINVDISK / 1024`
				;;
				-d)
					dskcmd="cd ${TEMPDINV};vgdisplay>xx.yy;grep 'VG Name' xx.yy>xx.aa;grep 'PE Size' xx.yy>xx.bb;grep 'Total PE' xx.yy>xx.cc;paste -d ' ' xx.aa xx.bb xx.cc|tr -s ' '|cut -d ' ' -f 3,7,10"
				;;
				*)
					DINVDISK=0
				;;
			esac
		;;

		Linux)
			case $det in
				-q)
					dskcmd="cd ${TEMPDINV};vgdisplay>xx.yy;grep 'PE Size' xx.yy>xx.bb;grep 'Total PE' xx.yy>xx.cc;paste -d ' ' xx.bb xx.cc|tr -s ' '|cut -d ' ' -f 4,8|awk 'OFMT = \"%.18g\" {print \$1 * \$2}'"
				;;
				-t)
					cd ${TEMPDINV}
					SL=vgdisplinux2
					>xx.yy
					if test -x $INVDIR/spatch.sh
					then
						sh $INVDIR/spatch.sh $SL "vgdisplay>xx.yy 2>/dev/null" 8 5
					fi
					if test $? -ne 0
					then
						DISTATUS="WARN:(`cat spatch_$SL.err`) ${DISTATUS}"
					else
						if grep 'PE Size' xx.yy>xx.bb
						then
							DINVDISK=`grep 'Total PE' xx.yy>xx.cc;paste -d ' ' xx.bb xx.cc|tr -s ' '|cut -d ' ' -f 4,8|awk 'OFMT = "%.18g" {print \$1 * \$2}'|awk 'OFMT = "%.15g" {s+=$1}END{print s}'`
							DINVDISK=`expr $DINVDISK / 1024`
						else
							> ss.ss
							fdisk -l > ff.ll 2>&1
							grep -i "doesn't contain a valid partition table" ff.ll > ee.ee
							cat ff.ll | grep "Disk .* GB" | awk '{print $2,$3}' | tr -d ":" | while read dd ss
							do
								if grep " ${dd} " ee.ee > /dev/null 2>&1
								then
									ign=$ss
								else
									ii=`echo $ss | cut -d '.' -f 1`
									DINVDISK=`expr $DINVDISK + $ii`
									echo $DINVDISK > ss.ss
								fi
							done
							DINVDISK=`cat ss.ss`
							[ "$DINVDISK" = "" ] && DINVDISK=0
						fi
					fi
				;;
				-d)
					dskcmd="cd ${TEMPDINV};vgdisplay>xx.yy;grep 'VG Name' xx.yy>xx.aa;grep 'PE Size' xx.yy>xx.bb;grep 'Total PE' xx.yy>xx.cc;paste -d ' ' xx.aa xx.bb xx.cc|tr -s ' '|cut -d ' ' -f 4,7,11"
				;;
				*)
					DINVDISK=0
				;;
			esac
		;;

		SunOS)
			cd ${TEMPDINV}
			format </dev/null >xx.yy 2>/dev/null &
			fmtpid=$!

			wpsmaxmin=1
			sleep 8
			while true
			do
				xpsout="`ps -fp $fmtpid | grep -v \" PID \"`"
				if [ "$xpsout" = "" ]
				then
					fmtpid=ok
					break
				fi
				if [ $wpsmaxmin -ge 5 ]
				then
					break
				fi
				sleep 60
				wpsmaxmin=`expr $wpsmaxmin + 1`
			done

			if [ "$fmtpid" != "ok" ]
			then
				DCOMMENT="${DCOMMENT}(SunOS'format'hung${wpsmaxmin}min.)"
			fi

			case $det in
				-q)
					dskcmd=""
				;;
				-t)
					cat xx.yy | grep " cyl " | while read dno dna did dgm
					do
						case $did in
							*SUN18G*) DISKSIZE=18 ;;
							*SUN36G*) DISKSIZE=36 ;;
							*SUN72G*) DISKSIZE=72 ;;
							*SUN146G*) DISKSIZE=146 ;;
							*) DISKSIZE=`echo $dgm | tr -d "[a-z]<>" | awk '{print int((($1*$2*$3*$4*512)/2097152)/1024)}'` ;;
						esac
						DINVDISK=`expr $DINVDISK + $DISKSIZE`
						echo $DINVDISK > ss.ss
					done
					test -s ss.ss && DINVDISK=`cat ss.ss`
					[ "$DINVDISK" = "" ] && DINVDISK=0
				;;
				-d)
					dskcmd=""
				;;
				*)
					DINVDISK=0
				;;
			esac
		;;

		*)
			DINVDISK=0
		;;

	esac

	#_______________________________ 
	#                               #
	#	e_n_d	disk		#
	#_______________________________#
	#

	DINVUSRK=`cat /etc/passwd | wc -l | tr -d " "`

	DINVGRPK=`cat /etc/group  | wc -l | tr -d " "`

	case $OPSYNAME in

		AIX)
			test -s /etc/exports && grep -v "^#" /etc/exports | grep -v "^$" > ${TEMPSTAB}
			DINVOLGR=`lsvg | wc -l | tr -d " "`
			DINVPVOL=`lspv | grep -i active | wc -l | tr -d " "`
			DINVLVOL=`lsvg | xargs lsvg -l | wc -l | tr -d " "`
			DINVLVOL=`expr $DINVLVOL - $DINVOLGR`
		;;

		HP-UX)
			test -s /etc/dfs/dfstab && grep -v "^#" /etc/dfs/dfstab | grep -v "^$" > ${TEMPSTAB}
			vgdisplay -v > ${TEMPDINV}/vv.vv 2> /dev/null
			DINVOLGR=`cat ${TEMPDINV}/vv.vv | grep "VG Name" | wc -l | tr -d " "`
			DINVPVOL=`cat ${TEMPDINV}/vv.vv | grep "PV Name" | wc -l | tr -d " "`
			DINVLVOL=`cat ${TEMPDINV}/vv.vv | grep "LV Name" | wc -l | tr -d " "`
		;;

		Linux)
			test -s /etc/exports && grep -v "^#" /etc/exports | grep -v "^$" > ${TEMPSTAB}
			vgdisplay > ${TEMPDINV}/vv.vv 2> /dev/null
			pvdisplay > ${TEMPDINV}/pp.pp 2> /dev/null
			lvdisplay > ${TEMPDINV}/ll.ll 2> /dev/null
			DINVOLGR=`cat ${TEMPDINV}/vv.vv | grep "VG Name" | wc -l | tr -d " "`
			DINVPVOL=`cat ${TEMPDINV}/pp.pp | grep "PV Name" | wc -l | tr -d " "`
			DINVLVOL=`cat ${TEMPDINV}/ll.ll | grep "LV Name" | wc -l | tr -d " "`
		;;

		SunOS)
			test -s /etc/dfs/dfstab && grep -v "^#" /etc/dfs/dfstab | grep -v "^$" > ${TEMPSTAB}
		;;

		*)
			DINVOLGR=n/a		# volume group count
			DINVPVOL=n/a		# physical volume count
			DINVLVOL=n/a		# logical volume count
		;;

	esac

	test -s ${TEMPSTAB} && cat ${TEMPSTAB} | sed "s/^/${DINVHOST};/" > ${INVEXP}

	mount | grep -i -v nfs > ${TEMPMTAB}
	mount | grep -i    nfs > ${TEMPMNFS}

	cat ${TEMPMTAB} | sed "s/^/${DINVHOST};/" > ${INVLFS}
	cat ${TEMPMNFS} | sed "s/^/${DINVHOST};/" > ${INVNFS}

	DINVFSYS=`cat $TEMPMTAB | wc -l | tr -d " "`

	mv ${TEMPMTAB} ${TEMPMTAB}_`date +%Y%m%d_%H%M%S`
	mv ${TEMPMNFS} ${TEMPMNFS}_`date +%Y%m%d_%H%M%S`

	#________________________________________________________________
	#

	cat $INVPIZ | grep _pmon_ | grep -v grep | tr "_" " " | awk '{print $NF}' | tr "\n" "," > ${TEMPDINV}/pp.pp
	if [ -s ${TEMPDINV}/pp.pp ]
	then
		DINVPMON=`( cat ${TEMPDINV}/pp.pp ; echo ) | sed "s/,$//"`
		for i in `echo $DINVPMON | tr "," " "`
		do
			echo "${TESTHOST}${INVSEP}${i}" >> $INVORA
		done
	fi

	#________________________________________________________________
	#

	DINVKEYF=${INVDIR}/${TESTHOST}.key
	[ -f $DINVKEYF ] && DINVUKEY=`cat $DINVKEYF`

	## DISTATUS=ok

	#________________________________________________________________
	#

	VMSTIDLE=100
	case $OPSYNAME$OPSYVERS in
		AIX5.3)	VMSTIDLE=`vmstat 1 1 | tail -1 | awk '{print $(NF-1)}'`	;;
		AIX6.1)	VMSTIDLE=`vmstat 1 1 | tail -1 | awk '{print $(NF-3)}'`	;;
		HP-UX*)	VMSTIDLE=`vmstat 1 1 | tail -1 | awk '{print $NF}'`	;;
		Linux*)	VMSTIDLE=`vmstat 1 1 | tail -1 | awk '{print $(NF-2)}'`	;;
		SunOS*)	VMSTIDLE=`vmstat 1 1 | tail -1 | awk '{print $NF}'`	;;
	esac
	VMSTIDLE=`echo $VMSTIDLE | cut -d '.' -f 1`
	DINVLOAD=`expr 100 - $VMSTIDLE`
	if test $DINVLOAD -gt 100
	then
		DINVLOAD="-`expr $DINVLOAD - 100`"
	fi
	DINVLOAD="${DINVLOAD}%,${UTLOAD}"

	#________________________________________________________________
	#

	if test "$OPSYNAME" = "Linux"
	then
		if type uptrack-show >/dev/null 2>&1
		then
			uptrack-show > ${TEMPDINV}/uu.tt 2>&1  ###  ${TEMPDINV}/uu.ee
			if test $? -eq 0
			then
				DINVUTUN="`cat ${TEMPDINV}/uu.tt | tail -1`"
			else
				DINVUTUN="problem(`head -1 ${TEMPDINV}/uu.tt`)"
			fi
		else
			DINVUTUN="not_found"
		fi
	else
		DINVUTUN="n/a"
	fi

	#________________________________________________________________
	#

	case $OPSYNAME in
		AIX)
			TEMPSOCS=`lscfg -vpl sysplanar0 | grep -i "[0-9]w proc"|wc -l|tr -d " "`
			test -n "${TEMPSOCS}" && DINVSOCS=$TEMPSOCS
			DINVCORS=$PROCOUNT
			FIRSTCPU=`lsdev -Cc processor|grep -i available|head -1 |cut -d ' ' -f 1`
			DINVSMTS=`lsattr -El ${FIRSTCPU}|grep smt_threads|cut -d ' ' -f 2`
			DINVTHRS=`bindprocessor -q|cut -d ':' -f 2 |wc -w|tr -d " "`
		;;
		HP-UX)
			DINVSOCS=n/a
		;;
		Linux)
			test -x $INVDIR/cpuinfo_Linux.sh && sh $INVDIR/cpuinfo_Linux.sh --fast > .ci.out 2>&1
			if test -s .ci.out
			then
				DINVSOCS=`grep "Total number of physical processors:" .ci.out | cut -d ':' -f 2 | tr -d " "`
				DINVCORS=`grep "Total number of cores:" .ci.out | cut -d ':' -f 2 | tr -d " "`
				DINVSMTS=`grep "Number of hardware threads " .ci.out | cut -d ':' -f 2 | tr -d " "`
				DINVTHRS=`grep "Number of virtual processors:" .ci.out | cut -d ':' -f 2 | tr -d " "`
			fi
		;;
		SunOS)
			test -x $INVDIR/cpuinfo_SunOS.sh && ksh $INVDIR/cpuinfo_SunOS.sh --fast > .ci.out 2>&1
			if test -s .ci.out
			then
				DINVSOCS=`grep "Total number of physical processors:" .ci.out | cut -d ':' -f 2 | tr -d " "`
				DINVCORS=`grep "Total number of cores:" .ci.out | cut -d ':' -f 2 | tr -d " "`
				DINVSMTS=`grep "Number of hardware threads " .ci.out | cut -d ':' -f 2 | tr -d " "`
				DINVTHRS=`grep "Number of virtual processors:" .ci.out | cut -d ':' -f 2 | tr -d " "`
			fi
		;;
	esac

	#________________________________________________________________
	#

	test "${MANMODEL}" != "n/a" && MANMODEL=`echo ${MANMODEL} | sed "s/ *//" | sed "s/ *$//" | tr -s " "`
	test "${VENDORID}" != "n/a" && VENDORID=`echo ${VENDORID} | sed "s/ *//" | sed "s/ *$//" | tr -s " "`
	test "${PROCNAME}" != "n/a" && PROCNAME=`echo ${PROCNAME} | sed "s/ *//" | sed "s/ *$//" | tr -s " "`

	#________________________________________________________________
	#

	if test -n "${LOCATION}"
	then
		DINVPLOC=${LOCATION}
	fi

	#________________________________________________________________
	#

	DINVVERS=$VERSION
}

dinvout () {
	dinvhour
	test -z "$DISTATUS" && DISTATUS=ok
#________________________________________________________________________________________________________________________________________________
#
#	corp	site	host	os	version	vendor	model	type	arch	cpu	count	clock	ram	swap	serial	ipv4	
#	center	center	left	left	right	center	center	center	center	center	right	right	right	right	right	right	
#
#	uptime	class	descr	comment	date	time
#	right	left	left	left	center	center	
#________________________________________________________________________________________________________________________________________________
#
	if [ $INVFMT = "new" ]
	then
		echo "${CORPNAME}${INVSEP}${SITENAME}${INVSEP}${DINVHOST}${INVSEP}${OPSYNAME}${INVSEP}${OPSYVERS}${INVSEP}${VENDORID}${INVSEP}${MANMODEL}${INVSEP}${MACHVIRT}${INVSEP}${PROCARCH}${INVSEP}${PROCNAME}${INVSEP}${PROCOUNT}${INVSEP}${PROCLOCK}${INVSEP}${RAMSIZEG}${INVSEP}${SWAPSIZE}${INVSEP}${HWSERIAL}${INVSEP}${IPV4ADDR}${INVSEP}${HCUPTIME}${INVSEP}${HOSTCLAS}${INVSEP}${HOSTDESC}${INVSEP}${DCOMMENT}${INVSEP}${DINVDATE}${INVSEP}${DINVTIME}${INVSEP}${DINVDISK}${INVSEP}${DINVUSRK}${INVSEP}${DINVGRPK}${INVSEP}${DINVOLGR}${INVSEP}${DINVPVOL}${INVSEP}${DINVLVOL}${INVSEP}${DINVFSYS}${INVSEP}${DINVPMON}${INVSEP}${DINVPERF}${INVSEP}${DNSERVER}${INVSEP}${DGATEWAY}${INVSEP}${DINVNICS}${INVSEP}${DINVIPAS}${INVSEP}${DINMASKS}${INVSEP}${DINVMACS}${INVSEP}${DISTATUS}${INVSEP}${DINVUKEY}${INVSEP}${DINVACIP}${INVSEP}${DINVHONA}${INVSEP}${DINVTIZO}${INVSEP}${DINVPLOC}${INVSEP}${DINVSOCS}${INVSEP}${DINVCORS}${INVSEP}${DINVSMTS}${INVSEP}${DINVTHRS}${INVSEP}${DINVTAGS}${INVSEP}${OPSYLEVL}${INVSEP}${DINVHBAS}${INVSEP}${DINVWWNS}${INVSEP}${DINVLOAD}${INVSEP}${VPGUESTS}${INVSEP}${DINVVLAN}${INVSEP}${DINVINAT}${INVSEP}${DINVRUNS}${INVSEP}${DINVVERS}${INVSEP}${PATCHDAY}${INVSEP}${DINVUTUN}" > $INVOUT
	else
		INVSEP="\" \""
		echo \"${CORPNAME}${INVSEP}${SITENAME}${INVSEP}${DINVHOST}${INVSEP}${OPSYNAME}${INVSEP}${OPSYVERS}${INVSEP}${VENDORID}${INVSEP}${MANMODEL}${INVSEP}${MACHVIRT}${INVSEP}${PROCARCH}${INVSEP}${PROCNAME}${INVSEP}${PROCOUNT}${INVSEP}${PROCLOCK}${INVSEP}${RAMSIZEG}${INVSEP}${SWAPSIZE}${INVSEP}${HWSERIAL}${INVSEP}${IPV4ADDR}${INVSEP}${HCUPTIME}${INVSEP}${HOSTCLAS}${INVSEP}${HOSTDESC}${INVSEP}${DCOMMENT}${INVSEP}${DINVDATE}${INVSEP}${DINVTIME}${INVSEP}${DINVDISK}${INVSEP}${DINVUSRK}${INVSEP}${DINVGRPK}${INVSEP}${DINVOLGR}${INVSEP}${DINVPVOL}${INVSEP}${DINVLVOL}${INVSEP}${DINVFSYS}${INVSEP}${DINVPMON}${INVSEP}${DINVPERF}${INVSEP}${DNSERVER}${INVSEP}${DGATEWAY}${INVSEP}${DINVNICS}${INVSEP}${DINVIPAS}${INVSEP}${DINMASKS}${INVSEP}${DINVMACS}${INVSEP}${DISTATUS}${INVSEP}${DINVUKEY}\" > $INVOUT
	fi
	cp -p $INVOUT $INVCSV
	[ $INVQUIET = false ] && cat $INVOUT
}

dinvsos () {
	dinvhour
	if test "$3" = "warn"
	then
		DISTATUS="WARN:($1)"
	else
		DISTATUS="ERR:($1)"
	fi
	DINVHOST=`echo $THISHOST | cut -d '.' -f 1`
	echo "${CORPNAME}${INVSEP}${SITENAME}${INVSEP}${DINVHOST}${INVSEP}${OPSYNAME}${INVSEP}${OPSYVERS}${INVSEP}${VENDORID}${INVSEP}${MANMODEL}${INVSEP}${MACHVIRT}${INVSEP}${PROCARCH}${INVSEP}${PROCNAME}${INVSEP}${PROCOUNT}${INVSEP}${PROCLOCK}${INVSEP}${RAMSIZEG}${INVSEP}${SWAPSIZE}${INVSEP}${HWSERIAL}${INVSEP}${IPV4ADDR}${INVSEP}${HCUPTIME}${INVSEP}${HOSTCLAS}${INVSEP}${HOSTDESC}${INVSEP}${DCOMMENT}${INVSEP}${DINVDATE}${INVSEP}${DINVTIME}${INVSEP}${DINVDISK}${INVSEP}${DINVUSRK}${INVSEP}${DINVGRPK}${INVSEP}${DINVOLGR}${INVSEP}${DINVPVOL}${INVSEP}${DINVLVOL}${INVSEP}${DINVFSYS}${INVSEP}${DINVPMON}${INVSEP}${DINVPERF}${INVSEP}${DNSERVER}${INVSEP}${DGATEWAY}${INVSEP}${DINVNICS}${INVSEP}${DINVIPAS}${INVSEP}${DINMASKS}${INVSEP}${DINVMACS}${INVSEP}${DISTATUS}${INVSEP}${DINVUKEY}${INVSEP}${DINVACIP}${INVSEP}${DINVHONA}${INVSEP}${DINVTIZO}${INVSEP}${DINVPLOC}${INVSEP}${DINVSOCS}${INVSEP}${DINVCORS}${INVSEP}${DINVSMTS}${INVSEP}${DINVTHRS}${INVSEP}${DINVTAGS}${INVSEP}${OPSYLEVL}${INVSEP}${DINVHBAS}${INVSEP}${DINVWWNS}${INVSEP}${DINVLOAD}${INVSEP}${VPGUESTS}${INVSEP}${DINVVLAN}${INVSEP}${DINVINAT}${INVSEP}${DINVRUNS}${INVSEP}${DINVVERS}${INVSEP}${PATCHDAY}${INVSEP}${DINVUTUN}" > $INVOUT
	cp -p $INVOUT $INVCSV
	[ $INVQUIET = false ] && cat $INVOUT
	test "$2" != "ok" && exit 1
}

dinvaround () {
	cat $INVPIZ | grep " ${INVSCR} ${THISHOST} " | grep -v " ${MYPID} " | grep -v grep > ${PSOUT} 2>&1
	rk=`grep -c " ${INVSCR} ${THISHOST} " ${PSOUT}`
	if test $rk -gt 2
	then
		if [ "$2" = "kill" ]
		then
			ps -fe | grep " ${INVSCR} " | grep -v " ${MYPID} " | grep -v grep | awk '{print $2}' | xargs -l kill -9
			sk=`ps -fe | grep " ${INVSCR} " | grep -v " ${MYPID} " | grep -v grep | wc -l | tr -d " "`
			kk=$rk
		else
			sk=`cat $INVPIZ | grep " ${INVSCR} " | grep -v " ${MYPID} " | grep -v grep | wc -l | tr -d " "`
			kk=0
		fi
		## dinvsos "found <$rk> running , <$kk> killed , <$sk> remain" "ok" "warn"
		test $DISTATUS = "n/a" && DISTATUS=""
		DISTATUS="WARN:(found <$rk> running) ${DISTATUS}"
		cp -p ${PSOUT} ${INVDIR}/found_${OUTSTAMP}
		sleep 10
	fi
}

dinvckup () {
	cp /dev/null ${INVDHN}/dinv.ckup
	echo "DINVUNAME=`uname -a 2>u.e`" >> ${INVDHN}/dinv.ckup
	echo "DINVCRONT=`crontab -l 2>c.e | grep /dinv.sh`" >> ${INVDHN}/dinv.ckup
	grep "VERSION=" ${INVDIR}/info.env >> ${INVDHN}/dinv.ckup 2> v.e
	echo "DINVCROND=`grep cron $INVPIZ 2>d.e | tr -s ' '`" >> ${INVDHN}/dinv.ckup
	echo "DINVHNAME=`hostname 2>h.e`" >> ${INVDHN}/dinv.ckup
	echo "`date`;${DINVHNAME};${DINVUNAME}" >> ${INVDIR}/dinvdna.csv
	#######################################################
	### SWD=`pwd`
	### cd $INVDIR
	### sh ./dinvrify.sh >> ${INVDHN}/dinv.ckup
	### if test $? -ne 0
	### then
	### 	DISTATUS="WARN:(tampering) ${DISTATUS}"
	### fi
	### cd $SWD
	#######################################################
	cat u.e c.e v.e d.e h.e > ${INVDHN}/dinv.cker
	dinvrm -f u.e c.e v.e d.e h.e
}

dinvend () {
	for i in $INVCSV $INVORA $INVNET $INVEXP $INVLFS $INVNFS $INVNIZ $INVPIZ $INVLIZ $INVMIZ $INVFIZ $INVIIZ $INVRIZ $INVKIZ
	do
		test -s $i && cp -p $i $INVDHN
	done
	for i in passwd group hosts resolv.conf nsswitch.conf
	do
		test -s /etc/$i && cp -p /etc/$i ${INVDHN}/dinv.${i}
	done
	test -d /tmp/reco.d && cp -p /tmp/reco.d/*.tar* ${INVDHN}
	crontab -l | sed "s/^/${THISHOST};/" > ${INVDHN}/dinv.crontab
	test -d $INVSUD && cp -rp $INVSUD $INVDHN
	cd $INVDIR
	rm -fr dico,*,tar
	DCT="dico,${THISHOST},tar"
	tar cf $DCT coletas
	cd /tmp
	dinvrm -fr $TEMPDINV $PSOUT ${COLDIR}/localckup.sh /tmp/reco.d /tmp/greco.d
	dinvrm -f clup.out clup.err /root/clup.out /root/clup.err /clup.out /clup.err
}

dinvlocal () {
	dinvinit
	dinvckup
	dinvaround
	dinvinq
	dinvout
	dinvend
	exit $ES
}

dinvhost () {
	if [ "$1" = "" ]
	then
		usage $BAC
	else
		test $INVQUIET = false && echo host $1
	fi
}

dinvlist () {
	if [ "$1" = "" ]
	then
		usage $BAC
	else
		test $INVQUIET = false && echo list $1
	fi
}

default () {
	dinvlocal
	exit $ES
}

usage () {
	cat <<EOT
use : $1 [options]
	--help		usage help
	--indulge	run unprivileged
	--local		inspect local host
	--version	show version
EOT
	ES=1
	exit $ES
}

#_______________________________________________________________________
#
#	main
#_______________________________________________________________________
#

ES=0	# exit status

if test -s ${INFOENV}
then
	. ${INFOENV}
	BVERSION=${VERSION}
	export VERSION
	BRELEASE=${RELEASE}
fi

umask 077

THISHOST=`hostname`
export THISHOST

PARMHOST=false

if [ $# -eq 0 ]
then
	default
else
	while [ $# -gt 0 ]
	do
		case $1 in
			--adapt)		### must be 1st arg
				shift
				AOS=`uname`
				case $AOS in
					AIX) ASH=/usr/bin/ksh ;;
					HP-UX) ASH=/usr/bin/ksh ;;
					Linux) ASH=/bin/bash ;;
					SunOS) ASH=/usr/bin/ksh ;;
					*)
						ASH=`which ksh`
						[ "$ASH" = "" ] && ASH=`which bash`
					;;
				esac
				if [ -x $ASH ]
				then
					echo $ASH $0 $THISHOST $*
					exec $ASH $0 $THISHOST $*
					exit $ES
				else
					echo "$0 : bad OS/SH ($AOS/$ASH)"
					exit 1
				fi
			;;
			--header) cat dinv.hdr ; default ;;
			--help) usage $BAC ;;
			--host) dinvhost "$2" ;;
			--indulge) shift ; indulgeflag=1 ;;
			--list) dinvlist "$2" ;;
			--local|--localhost) dinvlocal ;;
			--rogue) dinvaround "$2" ;;
			--quiet) shift ; INVQUIET=true ;;
			--verbose) shift ; VFLAG=true ;;
			--version) echo $VERSION ; exit 0 ;;
			-V) echo "$BAC $VERSION $RELEASE" ; exit 0 ;;
			$THISHOST) shift ; PARMHOST=true ;;
			*) usage $BAC ;;
		esac
	done
	if $PARMHOST
	then
		default
	fi
fi

exit $ES

#_______________________________________________________________#
#								#
# version   released   history
#  2.1.37  2011/05/05  launch stable
#  2.1.38  2011/09/09  self update, extra info
#  2.1.39  2011/09/12  hp-ux processors
#  2.1.43  2011/09/14  vendor, architecture, comment
#  2.1.45  2011/09/17  uptime, class, description
#  2.1.46  2011/09/22  virtualization
#  2.1.47  2012/12/07  fix cpu count
#  2.1.48  2013/03/13  output in quotes (php)
#_______________________________________________________________#
#								#
# vi:nu ts=8
