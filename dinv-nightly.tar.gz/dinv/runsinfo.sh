
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code in this file is part of "dinv" (dynamic inventory tool)   |
###   |   as released by alexandre botao <alexandre at botao dot org>         |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

TS="`cat ${INVDIR}/runsinfo.list`"
US="`cat ${INVDIR}/runsuser.list`"
runz () {
	HN=$1
	PS=$2
	cat <<EOI
		if test -z "${PS}"
		then
			ps -fe > /tmp/.x.o 2>&1
		else
			cat $PS > /tmp/.x.o 2>&1
		fi
		zero=\$?
		if test "\$zero" -eq 0
		then
			for T in $TS
			do
				if grep \$T /tmp/.x.o >/dev/null 2>&1
				then
					if test -z "\$TL"
					then
						TL="\$T"
					else
						TL="\$TL,\$T"
					fi
				fi
			done
			for U in $US
			do
				if grep "^\$U " /tmp/.x.o >/dev/null 2>&1
				then
					if test -z "\$TL"
					then
						TL="\$U"
					else
						TL="\$TL,\$U"
					fi
				fi
			done
			echo "${HN};\${TL}"
			rm -f /tmp/.x.o /tmp/.x.e
		else
			echo "${HN};err" ; exit 1
		fi
EOI
}
if test $# -eq 0
then
	HN=`hostname | cut -d '.' -f 1`
	runz $HN | sh
else
	for HN in $*
	do
		runz $HN | ssh $SSHOPT $HN "sh"
	done
fi
# vi:nu ts=4
