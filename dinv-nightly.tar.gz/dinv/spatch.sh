
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

##  __________________________________________________________________________
## |                                                                          |
## |  The source code in this file is part of the "dinv" software project     |
## |  as developed and released by alexandre botao <from botao dot org> ,     |
## |  available for download from the following public repositories:          |
## |                                                                          |
## |  https://sourceforge.net/u/avrbotao/                                     |
## |  https://gitlab.com/alexandre.botao/                                     |
## |  https://github.com/avrbotao/                                            |
## |                                                                          |
## |  This software is free and open-source: you can redistribute it and/or   |
## |  modify it under the terms stated on the GNU General Public License      |
## |  as published by the Free Software Foundation, either version 3 of the   |
## |  License, or (at your option) any later version.                         |
## |                                                                          |
## |   This code is distributed in the hope that it will be useful,           |
## |   but WITHOUT ANY WARRANTY; without even the implied warranty of         |
## |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                   |
## |   See the GNU General Public License for more details.                   |
## |                                                                          |
## |   You should have received a copy of the GNU General Public License      |
## |   along with this code.  If not, see <http://www.gnu.org/licenses/>,     |
## |   or write to the Free Software Foundation, Inc.,                        |
## |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.               |
## |__________________________________________________________________________|
##

#
#	spatch	(spawn + watch)		1.2.4		18-06-13	bud
#
BAC=spatch
usage () {
	echo "use: $1 <label> <\"command\"> <times> <seconds>" > $err
	exit 1
}
test $# -ne 4 && usage $BAC
lbl=$1
cmd=$2
max=$3
tim=$4
tmp=$PWD
## tmp=/tmp
log=${tmp}/${BAC}_${lbl}.log
err=${tmp}/${BAC}_${lbl}.err
rm -f $log $err
nohup sh -c "${cmd}" &
pid=$!
cnt=1
sleep 3 # head start
while true
do
        if ps -fp $pid >> $log
		then
        	date >> $log
        	sleep $tim
		else
			echo "task($cmd) took `expr $cnt \* $tim` seconds" >> $log
			exit 0
		fi
        if test $cnt -lt $max
        then
			cnt=`expr $cnt + 1`
        else
			echo "task($cmd) exceeds `expr $max \* $tim` seconds" > $err
			exit 2
        fi
done
# vi:nu ts=4
