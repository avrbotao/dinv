#
#	xsudo.sh	- collect/peruse sudoers stuff (based upon)
# parsesudo.sh	- Parse sudoers files and provides a defined output:
#
#					2016-06-03	RFB
#
#                   2019-12-09  botao solaris
#                   2019-12-10  botao collect
#
# [s:SERVER;]u:USER;h:HOST;r:RUNAS;c:COMMANDS
#
# This is useful for audit and to check sudoers privileges by script
#

umask 077

if test -z "$INVDIR"
then
	echo ">>> $0: INVDIR not set" >&2
	exit 1
else
	export INVDIR
fi

#_______________________________________________________________________#
#																		#
if [ "x$SUDOERSFILES" = "x" ]; then
	SUDOERSFILES="	etc/sudoers etc/sudoers.d/* usr/local/etc/sudoers \
			etc/local/etc/sudoers.d/* opt/iexpress/sudo/etc/sudoers \
			opt/iexpress/sudo/etc/sudoers.d/*"
fi

if [ "x$GROUPFILE" = "x" ]; then
	GROUPFILE="etc/group"
fi

if [ "x$PASSWDFILE" = "x" ]; then
	PASSWDFILE="etc/passwd"
fi
#_______________________________________________________________________#
#																		#
if [ "x$HOSTSFILE" = "x" ]; then
	HOSTSFILE="etc/hosts"
fi
#_______________________________________________________________________#
#																		#
if [ "x$IPTABFILE" = "x" ]; then
	IPTABFILE="tmp/iptables.save"
fi
### if [ "x$SYSCTLFILE" = "x" ]; then
### 	SYSCTLFILE="tmp/sysctl.save"
### fi
if [ "x$CRONFILE" = "x" ]; then
	CRONFILE="tmp/croninfo.csv"
fi
if [ "x$ROUTEFILE" = "x" ]; then
	ROUTEFILE="tmp/routeinfo.csv"
fi
#_______________________________________________________________________#
#																		#

LOS=`uname`

if test "$1" = "--offline"
then
	shift
	WDIR=$1
	if test -z "${WDIR}"
	then
		echo ">>> missing work dir <<<"
		exit 1
	else
		if test -d ${WDIR}
		then
			shift
			cd ${WDIR}
		else
			echo ">>> not a dir (${WDIR}) <<<"
			exit 1
		fi
	fi
else
	test -d /tmp/xsudo && rm -fr /tmp/xsudo		# deprecated
	XTMP=/tmp/xsudo.d
	test -d ${XTMP} && rm -fr ${XTMP}
	mkdir ${XTMP}

	HRUN=`hostname | cut -d '.' -f 1`

    if test -s ${INVDIR}/host.info
	then
		. ${INVDIR}/host.info
		HRUN=$DINVHOST
	fi

	DRUN=${XTMP}/${HRUN}
	mkdir ${DRUN}

	cd /

	rm -f $SYSCTLFILE $IPTABFILE $CRONFILE $ROUTEFILE tmp/*ck.out 2>/dev/null

	### FIXME: detect running pw,grp-ck / semaph / lock-wait max N x M secs (eg solaris global)
	> tmp/ck.list
	for K in pwck grpck
	do
		if type $K >/dev/null 2>&1
		then
			if test "$LOS" = "HP-UX"
			then
				$K > tmp/${K}.out 2>&1
				$K -s >> tmp/${K}.out 2>&1
				$K -l >> tmp/${K}.out 2>&1
				echo tmp/${K}.out >> tmp/ck.list
			elif test "$LOS" = "Linux"
			then
				$K -r > tmp/${K}.out 2>&1
				echo tmp/${K}.out >> tmp/ck.list
			else
				$K > tmp/${K}.out 2>&1
				echo tmp/${K}.out >> tmp/ck.list
			fi
		fi
	done
	test -s tmp/ck.list && CKFILES="`cat tmp/ck.list`"

	if type iptables-save >/dev/null 2>&1
	then
		iptables-save > $IPTABFILE 2> /dev/null
### else
###		cp /dev/null $IPTABFILE
	fi

### 	if type sysctl >/dev/null 2>&1
### 	then
### 		sysctl -a > $SYSCTLFILE 2> /dev/null
### 	fi

	if test -s ${INVDIR}/croninfo.sh >/dev/null 2>&1
	then
		sh ${INVDIR}/croninfo.sh > $CRONFILE 2> /dev/null
	fi

	if test -s ${INVDIR}/routeinfo.sh >/dev/null 2>&1
	then
		sh ${INVDIR}/routeinfo.sh > $ROUTEFILE 2> /dev/null
	fi

	### test "$LOS" = "SunOS" && FOL=-follow

	find $SUDOERSFILES $IPTABFILE $CRONFILE $ROUTEFILE $CKFILES -print 2>/dev/null | cpio $FOL -pdum ${DRUN} >/dev/null 2>&1
	cd $DRUN
fi

if test "$1" = "--collect"
then
	### find $DRUN -print
	cd /
	rm -f tmp/ck.list $IPTABFILE $CRONFILE $ROUTEFILE $CKFILES 2>/dev/null
	exit 0
fi

#_______________________________________________________________________#
#																		#

# Clear temporary files
#
> rules.int
> rules.org
> params.int
> params.org

# Split params and rules in separated files
#
grep -vhE '^#|^$|^Defaults' $SUDOERSFILES 2>/dev/null | \
	sed -e 's/,[^ ]/, /g' | sed -e 's/\\[[:blank:]]*$/\\/' -e 's/,[[:blank:]]*$/, \\/' |\
	awk '/\\$/ { printf("%s",$0) } !/\\$/ { print $0 }' | \
	tr -d '\\' | tr -s '	 ' ' ' | \
	awk '!/_Alias/ { print $0 >> "rules.org" }
	     /_Alias/  { print $0 >> "params.org" }'

# Put rules in a defined format 
#
while read line ; do
	NAME="$(echo $line | cut -f1 -d=)"
	NAME=$(echo $NAME | sed -e 's/\([%a-zA-Z0-9_]*\) *\([a-zA-Z0-9_-]*\) */\1|\2/')
	for i in $(echo $line | cut -f2- -d= | sed -e 's/[A-Za-z_-]*: *//g' -e 's/ /__/g' -e 's/,__/ /g' -e 's/__,/ /g' -e 's/^__/ /g'); do
	    if [ $(echo $i | grep -c '(.*)') = 0 ]; then
		LINE="ALL|$i"
	    else
		LINE="$(echo $i | sed -e 's/.*(\([a-zA-Z0-9_]*\))__/\1|/')"
	    fi
	    echo "$NAME|$LINE"
	done
done < rules.org > rules.int

cat params.org | sort -u | sed -e 's/\*/\\*/g' -e 's/\[/\\[/g' -e 's/\]/\\]/g' -e "s/[']/\\\'/g" -e 's/["]/\\"/g' -e 's/ /__/g' > params.int

while read line ; do
        ALIAS="$(echo $line | cut -f1 -d= | sed -e 's/__/ /g')"
        CMD="$(echo $line | cut -f2- -d= | sed -e 's/ /__/g' -e 's/,__/ /g' -e 's/__,/ /g' -e 's/^__/ /g')" 
        echo "$ALIAS = $CMD"
done < params.int > params.nml
mv params.nml params.int

# Unroll alias in sudoers
#
unroll_cmnd() {
	User=$1
	Host=$2
	Runas=$3
	for j in $(echo $Cmnd | sed -e 's/\*/\\*/g' -e 's/\[/\\[/g' -e 's/\]/\\]/g' -e "s/[']/\\\'/g" -e 's/["]/\\"/g') ; do
		YESNO=y
		if [ "x$(echo $j | cut -c1)" = "x!" ]; then
			YESNO=n
			j=$(echo $j | cut -c2-)
		fi
		if [ $(grep -c "Cmnd_Alias $j *=" params.int) -eq 0 ]; then
			echo "u:$User;h:$Host;r:$Runas;$YESNO:$j"
		else
		   YESNO_F=$YESNO
	   	   for i in $(grep "Cmnd_Alias $j *=" params.int | cut -f2- -d\= | sed -e 's/\*/\\*/g' -e 's/\[/\\[/g' -e 's/\]/\\]/g' -e "s/[']/\\\'/g" -e 's/["]/\\"/g'); do
			YESNO=$YESNO_F
			if [ "x$(echo $i | cut -c1)" = "x!" ]; then
				if [ "$YESNO" = "y" ]; then
					YESNO=n
				else
					YESNO=y
				fi
				i=$(echo $i | cut -c2-)
			fi
			echo "u:$User;h:$Host;r:$Runas;$YESNO:$i"
	   	   done
		fi
	done
}	

unroll_runas() {
	User=$1
	Host=$2
	if [ $(grep -c "Runas_Alias $Runas *=" params.int) -eq 0 ]; then
		unroll_cmnd $User $Host $Runas
	else
	   for i in $(grep "Runas_Alias $Runas *=" params.int | cut -f2- -d\=); do
		unroll_cmnd $User $Host $i
	   done
	fi
}

unroll_host() {
	User=$1
	if [ $(grep -c "Host_Alias $Host *=" params.int) -eq 0 ]; then
		unroll_runas $User $Host
	else
	   for i in $(grep "Host_Alias $Host *=" params.int | cut -f2- -d\=); do
		unroll_runas $User $i
	   done
	fi
}	

unroll_group() {
	User=$1
	if [ "$(echo $User | cut -c1)" != "%" ]; then
		unroll_host $User
	else
	   GRNAME=$(echo $User | cut -c2-)
	   GRID=$(grep "^$GRNAME:" $GROUPFILE | cut -f3 -d:)
	   if [ "x$GRID" = "x" ]; then
		unroll_host ${GRNAME}_NOT_FOUND
	   else
		   GRUSERS="$(grep "^$GRNAME:" $GROUPFILE | cut -f4- -d: | tr , \ ) $(grep -E "^[^:]*:[^:]*:[^:]*:$GRID:" $PASSWDFILE | cut -f1 -d:)"
		   if [ "$(echo $GRUSERS | grep -c '[A-Za-z0-9_]')" = "0" ]; then
			unroll_host ${GRNAME}_EMPTY
		   else
			   for i in $GRUSERS ; do
				unroll_host $i
			   done
		   fi
	   fi
	fi
}

unroll_user() {
	if [ $(grep -c "User_Alias $User *=" params.int) -eq 0 ]; then 
		unroll_group $User
	else 
	   for i in $(grep "User_Alias $User *=" params.int | cut -f2- -d\=); do
		unroll_group $i
	   done
	fi
}

mv rules.int rules.nml
while read line ; do 
	User=$(echo $line | cut -f1 -d\|)
	Host=$(echo $line | cut -f2 -d\|)
	Runas=$(echo $line | cut -f3 -d\|)
	Cmnd="$(echo $line | cut -f4- -d\|)"
	unroll_user
done < rules.nml > rules.int
sed -e 's/__/ /g' -e 's/\\//g' rules.int | sort -u > rules.nml
# vi:nu ts=4
