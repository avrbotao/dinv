
### 
###           |          _                   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
###           |\       _/ \_                 |       alexandre  botao       |
###           | \_    /_    \_               |         botao dot org        |
###           \   \__/  \__   \              |       +55-11-98244-UNIX      |
###            \_    \__/  \_  \             |       +55-11-9933-LINUX      |
###              \_   _/     \ |             |  alexandre at botao dot org  |
###                \_/        \|             |      botao at unix  dot net  |
###                            |             |______________________________|
### 

###    _______________________________________________________________________
###   |                                                                       |
###   |   This code in this file is part of "dinv" (dynamic inventory tool)   |
###   |   as developed and released by alexandre botao <from botao dot org> , |
###   |   available for download from the following public repositories:      |
###   |                                                                       |
###   |   https://sourceforge.net/u/avrbotao/                                 |
###   |   https://gitlab.com/alexandre.botao/                                 |
###   |   https://github.com/avrbotao/                                        |
###   |                                                                       |
###   |   This code is free software: you can redistribute it and/or modify   |
###   |   it under the terms of the GNU General Public License as published   |
###   |   by the Free Software Foundation, either version 3 of the License,   |
###   |   or (at your option) any later version.                              |
###   |                                                                       |
###   |   This code is distributed in the hope that it will be useful,        |
###   |   but WITHOUT ANY WARRANTY; without even the implied warranty of      |
###   |   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                |
###   |   See the GNU General Public License for more details.                |
###   |                                                                       |
###   |   You should have received a copy of the GNU General Public License   |
###   |   along with this code.  If not, see <http://www.gnu.org/licenses/>,  |
###   |   or write to the Free Software Foundation, Inc.,                     |
###   |   59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.            |
###   |_______________________________________________________________________|
###

hostnicz () {
	HN=$1
	cat <<EOI
		case \`uname\` in
			Linux)
				mark="Link | flags="
				ifconfig -a > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			AIX|SunOS)
				mark=" flags="
				ifconfig -a > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			HP-UX)
				mark=" flags="
				netstat -in 2>/dev/null | grep -v "^Name" | cut -d ' ' -f 1 | xargs -l ifconfig > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			*) echo "${HN};O.S. (\`uname\`) unprepared" ; exit 1 ;;
		esac
		if test "\$zero" -eq 0
		then
			while read line
			do
				if test -z "\${line}"
				then
					PFX=void
					DAT=empty
				else
					if echo "\${line}" | egrep -e "\${mark}" >/dev/null 2>&1
					then
						PFX=\`echo \${line} | cut -d ' ' -f 1\`
						DAT=\`echo \${line} | cut -d ' ' -f 2-\`
					else
						DAT=\`echo \${line}\`
					fi
				fi
				echo "${HN};\${PFX};<\${DAT}>"
			done < /tmp/.x.o
			rm -f /tmp/.x.o /tmp/.x.e
		else
			echo "${HN};unsearchable" ; exit 1
		fi
EOI
}
if test $# -eq 0
then
	HN=`hostname | cut -d '.' -f 1`
	hostnicz $HN | sh
else
	for HN in $*
	do
		hostnicz $HN | ssh $SSHOPT $HN "sh"
	done
fi
# vi:nu ts=4
