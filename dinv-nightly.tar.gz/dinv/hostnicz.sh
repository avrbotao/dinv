hostnicz () {
	HN=$1
	cat <<EOI
		case \`uname\` in
			Linux)
				mark="Link | flags="
				ifconfig -a > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			AIX|SunOS)
				mark=" flags="
				ifconfig -a > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			HP-UX)
				mark=" flags="
				netstat -in 2>/dev/null | grep -v "^Name" | cut -d ' ' -f 1 | xargs -l ifconfig > /tmp/.x.o 2> /tmp/.x.e
				zero=\$?
			;;
			*) echo "${HN};O.S. (\`uname\`) unprepared" ; exit 1 ;;
		esac
		if test "\$zero" -eq 0
		then
			while read line
			do
				if test -z "\${line}"
				then
					PFX=void
					DAT=empty
				else
					if echo "\${line}" | egrep -e "\${mark}" >/dev/null 2>&1
					then
						PFX=\`echo \${line} | cut -d ' ' -f 1\`
						DAT=\`echo \${line} | cut -d ' ' -f 2-\`
					else
						DAT=\`echo \${line}\`
					fi
				fi
				echo "${HN};\${PFX};<\${DAT}>"
			done < /tmp/.x.o
			rm -f /tmp/.x.o /tmp/.x.e
		else
			echo "${HN};unsearchable" ; exit 1
		fi
EOI
}
if test $# -eq 0
then
	HN=`hostname | cut -d '.' -f 1`
	hostnicz $HN | sh
else
	for HN in $*
	do
		hostnicz $HN | ssh $SSHOPT $HN "sh"
	done
fi
# vi:nu ts=4
